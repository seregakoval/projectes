#!/bin/bash

DIR="~/public_html";

echo "start deploy..."

ssh  -p 22 -q -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no segmatic@52.209.55.60 <<EOF
cd $DIR &&  git fetch origin
cd $DIR && git reset --hard origin/master
cd $DIR && bower install
cp version.txt version_parent.txt && git log --pretty=format:'%h %an(%ae) - %B' --abbrev-commit --date=short -1 > version.txt
EOF

echo "done..."
