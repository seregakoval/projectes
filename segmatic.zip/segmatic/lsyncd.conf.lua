settings {
   logfile = "/tmp/lsyncd.log",
   statusFile = "/tmp/lsyncd.status",
   nodaemon = true,
}
sync {
    default.rsyncssh,
    source="/data/project/segmatic/",
    host="koval-sa@gbksoft.net",
    targetdir="segmatic/",
    delete="running",
    exclude={ ".git", "statics/*", "frontend/runtime/*", "backend/runtime/*", "console/runtime/*" },
    delay=0,
    rsync = {
        compress = true,
    }
}