require 'compass/import-once/activate'

http_path = "/"
css_dir = "css"
sass_dir = "sass"
images_dir = "img"
javascripts_dir = "js"

sass_options = {:sourcemap => true}

output_style = :compressed 

line_comments = true
