<?php

$sendTo = 'support@kmapreports.com';
$ip = $_SERVER['REMOTE_ADDR'];
if (in_array($ip, ['95.67.74.162', '127.0.0.1'])) {
    $sendTo = 'denis.nechepurenko@gmail.com';
} elseif (in_array($ip, [])) {
    $sendTo = 'natasv.zp@gmail.com';
}

return (object)[
    'from' => 'contact@kmap.io',
    'sendTo' => $sendTo,
    'sparkpostKey' => '47c85e29432c93116f36d00fa62b2deccbb36c13',
    'recaptchaSecret' => '6LfZHQsUAAAAALr5OYjZpA5c17SLkhaG3cOv_2KD',
];
