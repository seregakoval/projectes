<?php

use SparkPost\SparkPost;
use GuzzleHttp\Client;
use Http\Adapter\Guzzle6\Client as GuzzleAdapter;
use ReCaptcha\ReCaptcha;

class Contact
{
    protected $config;

    public function __construct()
    {
        $this->config = require('config.php');
    }

    protected function getParam($name)
    {
        return isset($_REQUEST[$name]) ? trim($_REQUEST[$name]) : '';
    }

    protected function getParams()
    {
        $name = $this->getParam('name');
        $email = $this->getParam('email');
        $subject = $this->getParam('subject');
        $phone = $this->getParam('phone');
        $message = $this->getParam('message');

        $errors = [];
        if ($name === '') {
            $errors['name'] = 'Empty full name';
        }
        if ($email === '') {
            $errors['email'] = 'Empty email';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Invalid email';
        }
        if ($subject === '') {
            $errors['subject'] = 'Empty reason';
        }
        if ($message === '') {
            $errors['message'] = 'Empty message';
        }

        if (!$this->captchaValidation($this->getParam('response'), $_SERVER['REMOTE_ADDR'])) {
            $errors['response'] = 'CAPTCHA test failed';
        }

        return [
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'phone' => $phone,
            'message' => $message,

            'errors' => $errors,
        ];
    }

    protected function captchaValidation($value, $remoteIp)
    {
        $recaptcha = new ReCaptcha($this->config->recaptchaSecret);
        $resp = $recaptcha->verify($value, $remoteIp);
        //$errors = $resp->getErrorCodes();
        return $resp->isSuccess();
    }

    protected function successResponse($data)
    {
        header('Content-Type: application/json');
        echo json_encode([
            'code' => 200,
            'result' => $data,
            'status' => 'success',
        ]);
        exit;
    }

    protected function errorResponse($statusCode, $message = null, $data = [])
    {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode([
            'code' => $statusCode,
            'result' => [],
            'status' => 'error',
            'message' => $message,
        ]);
        exit;
    }

    public function run()
    {
        $params = $this->getParams();

        $errors = $params['errors'];
        if (count($errors)) {
            $this->errorResponse(422, $errors, 'Validation error');
        }

        try {
            $response = $this->sendEmail($params);
            $body = is_object($response) ? $response->getBody() : null;
            $this->successResponse(isset($body['results']) ? $body['results'] : []);
        } catch (\Exception $e) {
            $this->errorResponse(500, 'Internal server error');
        }
    }

    public function sendEmail($params)
    {
        $name = $params['name'];
        $email = $params['email'];
        $subject = $params['subject'];
        $phone = $params['phone'];
        $message = $params['message'];

        $text = "Message from: $name ($email)\n";
        $text .= "Reason for inquiry: $subject\n";
        $text .= "Phone: $phone\n";
        $text .= "\n";
        $text .= "$message\n";

        $httpClient = new GuzzleAdapter(new Client());
        $sparky = new SparkPost($httpClient, ['key' => $this->config->sparkpostKey]);
        $promise = $sparky->transmissions->post([
            'content' => [
                'from' => [
                    'name' => $name,
                    'email' => $this->config->from,
                ],
                'subject' => 'Contact form: ' . $subject,
                'html' => nl2br(htmlspecialchars($text)),
                'text' => $text,
                'reply_to' => $email,
            ],
            //'substitution_data' => ['name' => 'YOUR_FIRST_NAME'],
            'recipients' => [
                [
                    'address' => [
                        //'name' => 'Denis',
                        'email' => $this->config->sendTo,
                    ],
                ],
            ],
        ]);

        $response = $promise->wait();
        return $response;
    }
}
