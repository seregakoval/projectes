<?php

require 'src/vendor/autoload.php';
require 'src/Contact.php';

$contact = new Contact();
$contact->run();
