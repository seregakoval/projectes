// A simple module to replace `Backbone.sync` with in memory storage. Models are given GUIDS, and saved into a JSON
// object. The store can then be used in order to populate views and also hold the data to be sent to the server for
// saving.

// Generate four random hex digits.
function S4() {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}
;

// Generate a pseudo-GUID by concatenating random hexadecimal.
function guid() {
    return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}
;

// Our Store is represented by a single JS object in *localStorage*. Create it
// with a meaningful name, like the name you'd give a table.
var Store = function (name, data) {

    function toObject(arr) {
        var rv = {};
        for (var i = 0; i < arr.length; ++i)
            if (arr[i] !== undefined) rv[i] = arr[i];
        return rv;
    }

    function isArray(input) {
        return typeof(input) == 'object' && (input instanceof Array);
    }

    //When the option is empty, the server will throw back an empty array
    //data need to be an object and not an array, otherwise it won't
    //save correctly. We check if the data we're instantiating with is
    //an array and convert it if it is.
    if (isArray(data)) data = toObject(data);

    this.name = name;
    this.data = data || {};

    this.modified = false;


};

_.extend(Store.prototype, {

    // We don't do anything here -- we don't need to save to localstorage. We're just
    //using in memory model representations bootstrapped from the server.
    save:function () {
//        localStorage.setItem(this.name, JSON.stringify(this.data));
    },

    // Add a model, giving it a (hopefully)-unique GUID, if it doesn't already
    // have an id of it's own.
    create:function (model) {
        if (!model.id) model.id = model.attributes.id = guid();
        this.data[model.id] = model;
        this.save();
        this.trigger('modified', 'create');
        return model;
    },

    // Update a model by replacing its copy in `this.data`.
    update:function (model) {
        this.data[model.id] = model;
        this.save();
        this.trigger('modified', 'update');
        return model;
    },

    // Retrieve a model from `this.data` by id.
    find:function (model) {
        return this.data[model.id];
    },

    // Return the array of all models currently in storage.
    findAll:function () {
        return _.values(this.data);
    },

    // Delete a model from `this.data`, returning it.
    destroy:function (model) {
        delete this.data[model.id];
        this.save();
        this.trigger('modified', 'destroy');
        return model;
    }

});

_.extend(Store.prototype, Backbone.Events);


// Override `Backbone.sync` to use delegate to the model or collection's
// *memStorage* property, which should be an instance of `Store`.
Backbone.sync = function (method, model, options) {

    var resp;
    var store = model.memStorage || model.collection.memStorage;


    switch (method) {
        case "read":
            resp = model.id ? store.find(model) : store.findAll();
            break;
        case "create":
            resp = store.create(model);
            break;
        case "update":
            resp = store.update(model);
            break;
        case "delete":
            resp = store.destroy(model);
            break;
    }

    if (resp) {
        options.success(resp);
    } else {
        options.error("Record not found");
    }
};