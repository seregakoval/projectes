<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Hiron
 * Date: 9/28/12
 * Time: 9:58 AM
 * To change this template use File | Settings | File Templates.
 */
if (!function_exists('_log')) {
    function _log($message)
    {
        if (is_array($message) || is_object($message)) {
            error_log(print_r($message, true));
        }
        else {
            error_log($message);
        }
    }
}

//If the theme has already loaded mobile detect, then don't bother. Otherwise,
//load mobile detect for mobile device support
if (!class_exists('Mobile_Detect')) {
    include 'lib/Mobile_Detect.php';
}

class USliderFrontendApp
{
    public $detect;
    public $hasVimeoEmbed;

    function __construct()
    {
        $this->detect = new Mobile_Detect();
        $this->hasVimeoEmbed = false;

        add_action('uslider', array($this, 'renderSlider'));
        add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));

        add_filter('usliderWrapperClasses', array($this, 'mobileClassesFilter'));
    }

    function pageHasSlider()
    {
        $retVal = ($this->getSelectedSliderID()) ? true : false;
        return $retVal;
    }

    function getSelectedSliderID()
    {
        //figure out if a slider should be rendered on this page by checking it's
        //custom post data
        global $post;
        global $wp_query;

        $page_id = $wp_query->get_queried_object_id();

        if ($page_id) {
            $selectedSliderID = get_post_meta($page_id, USLIDER_POST_META_KEY, true);
            return $selectedSliderID;
        }
        else return false;
    }

    function getSliderAttIDs()
    {
        return PrimePluginCommon::getSliderAttIDs();
    }

    function enqueueScripts()
    {
        if ($this->pageHasSlider()) {
            //output base slider markup and import JS app for the slider

            //import slider js
            $baseURL = USLIDER_ROOT_URI;

            wp_enqueue_style('animate-css', $baseURL . 'frontend/css/animate.css');
            wp_enqueue_style('font-awesome', $baseURL . 'frontend/css/fonts.css');

            /*
            * Backbone and its prequisites
            */
            wp_enqueue_script('json2', $baseURL . 'js/json2.js', array(), false, true);

            /*
            * Backbone Plugins/Extensions
            */
            wp_enqueue_script('backbone-localstorage', $baseURL . 'js/backbone.memstore.js',
                array('json2', 'backbone'), false, true);
            wp_enqueue_script('backbone-relational', $baseURL . 'js/backbone-relational.js',
                array('json2', 'backbone'), false, true);

            wp_enqueue_script('jquery-easing', $baseURL . 'js/jquery.easing.js', array('jquery'), false, true);
            wp_enqueue_script('flexslider', $baseURL . 'js/jquery.flexslider.js', array('jquery', 'jquery-easing'), false, true);

            wp_enqueue_script('fitvids', $baseURL . 'js/jquery.fitvids.js', array('jquery'), false, true);


            //Our plugin JS files start getting enqueued here

            wp_enqueue_script('uslider-models', $baseURL . '/js/models-min.js', array('backbone', 'backbone-localstorage', 'jquery', 'backbone-relational'));

            wp_localize_script('uslider-models', 'prime_sb_bootstrap_models', $this->getModels());

            $frontendDeps = array('uslider-models', 'flexslider', 'fitvids');

            if ($this->hasVimeoEmbed) {
                wp_enqueue_script('froogaloop', $baseURL . 'js/froogaloop.min.js', array(), false, true);
                $frontendDeps[] = 'froogaloop';
            }

            wp_enqueue_script('uslider-frontend', $baseURL . 'frontend/js/uslider-min.js',
                $frontendDeps, false, true);

            //UNCOMMENT FOR MIN
//            wp_enqueue_script('uslider-frontend', $baseURL . 'frontend/js/uslider-min.js',
//                $frontendDeps, false, true);

            wp_enqueue_style('flexslider', $baseURL . 'css/flexslider.css');

            //localize with the correct slider ID
            wp_localize_script('uslider-frontend', 'adapUS_slider_id', $this->getSelectedSliderID());
            wp_localize_script('uslider-frontend', 'adapUS_ajaxurl', admin_url('admin-ajax.php'));

            $attachment_ids = $this->getSliderAttIDs();
            $retHash = array();
            foreach ($attachment_ids as $id) {
                $imageSrc = wp_get_attachment_image_src($id, 'full');
                $imageSrc = $imageSrc[0];
                $retHash[$id] = array('src' => $imageSrc);
            }

            wp_localize_script('uslider-frontend', 'adapUS_sliderAttInfo', $retHash);


            //shove out a base div to have DOM entrance point
            //for appends
        }
    }

    /**
     * Get the models and also take care of calling things like do_shortcode on the content
     * @return mixed|void
     */
    function getModels()
    {
        $sliderModels = get_option(USLIDER_MODEL_WP_OPTION_NAME);

        if (isset($sliderModels['prime-sb-layers'])) {
            $layers = &$sliderModels['prime-sb-layers'];

            foreach ($layers as &$l) {
                if ($l['type'] == 'mobileContent' || $l['type'] == 'desktopContent') {
                    $cVal = $l['content'];
//                    $cVal = ict_t('uSlider', $l['title']);
                    $l['content'] = do_shortcode($cVal);
                }
                else if ($l['type'] == 'mobileVideo' || $l['type'] == 'desktopVideo') {
                    //do oEmbed call on the Video and shove it into the content field.
                    $embedContent = $l['embed']; //sprintf('[embed]%s[/embed]', $l['embed']);


                    if (strpos($embedContent, 'vimeo') !== false) {
                        $this->hasVimeoEmbed = true;
                    }

                    $wp_embed = new WP_Embed();
                    $embedContent = $wp_embed->autoembed($embedContent);

                    $l['content'] = $embedContent;

                    if (strpos($embedContent, 'youtu') !== false) {
                        wp_enqueue_script('youtube-iframe-api', 'http://www.youtube.com/iframe_api');
                    }
                }
            }
        }

        return $sliderModels;
    }

    function mobileClassesFilter($classes)
    {
        if ($this->is_mobile_device()) {
            $classes .= ' ' . 'mobile';
        }

        if ($this->detect->isIphone()) {
            $classes .= ' ' . 'iphone';
        }

        if($this->is_tablet_device()){
            $classes .= ' tablet-device';
        }


        $classes = trim($classes);
        return $classes;
    }

    function is_mobile_device()
    {
        return $this->detect->isMobile() && !$this->detect->isTablet();
    }

    function is_tablet_device()
    {
        return $this->detect->isTablet();
    }

    function renderSlider()
    {
        $classes = apply_filters('usliderWrapperClasses', '');
        ?>
    <div id="universalSliderWrapperDesktop" class="hidden <?php echo $classes; ?>">

    </div>
    <div id="universalSliderWrapperMobile" class="hidden <?php echo $classes; ?>"></div>

    <script id="uSliderTemplate" type="text/template">
        <div class="top-shadow-fallback"></div>
        <div class="universalSlider flexslider">
            <ul class="slides">

            </ul>
        </div>
        <div class="universalSliderControls"></div>
        <div class="bottom-shadow-fallback"></div>
    </script>

    <script id="uSlideTemplate" type="text/template">
        <div class="slide-inner">

        </div>
    </script>

    <script id="usLayerTemplate" type="text/template">
        <div class="layer-content">

        </div>
    </script>

    <script id="usControlsTemplate" type="text/template">
        <ul class="slider-nav desktop-slider-nav">
            <!-- Paginators go here -->
            <li class="play-button">Play</li>
        </ul>
        <div class="ie-arrows-wrapper">
        <ul class="ie-arrows">
            <li class="nav-arrow nav-arrow-back enabled ie-nav-arrow hidden"></li>
            <li class="nav-arrow nav-arrow-next enabled ie-nav-arrow hidden"></li>
        </ul>
        </div>
    </script>

    <script id="usMobileControlsTemplate" type="text/template">
        <ul class="slider-nav mobile-slider-nav">
            <li class="nav-arrow nav-arrow-back enabled">Previous</li>
            <!-- Paginators go here -->
            <li class="nav-arrow nav-arrow-next enabled">Next</li>
        </ul>
    </script>

    <?php
    }
}

$uslider_frontend = new USliderFrontendApp();

