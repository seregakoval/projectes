<?php
/*
Plugin Name: uSlider
Plugin URI: http://wpadaptive.com/pax/preview
Description: A multi-layer, animated slider
Version: 1.1.0
Author: Adaptive Themes
*/
?>
<?php

if (!defined("PRIME_CURRENT_PAGE"))
    define("PRIME_CURRENT_PAGE", basename($_SERVER['PHP_SELF']));

if (!defined("IS_ADMIN"))
    define("IS_ADMIN", is_admin());

if (!defined("USLIDER_MODEL_WP_OPTION_NAME"))
    define("USLIDER_MODEL_WP_OPTION_NAME", 'prime_slider_models');

if (!defined('USLIDER_POST_META_KEY')) {
    define("USLIDER_POST_META_KEY", 'uslider_slider_id');

}

$folder = basename(dirname(__FILE__));


define('USLIDER_ROOT_URI', trailingslashit(plugins_url($folder)));


define("USLIDER_MIN_WP_VERSION", '3.2');

require_once(WP_PLUGIN_DIR . '/' . basename(dirname(__FILE__)) . "/prime-common.php");


add_action('init', array('USlider', 'init'));

class USlider
{
    public static function init()
    {
        require_once(PrimePluginCommon::get_base_path() . "/admin/ajax.php");

        //If the Administrative Dashboard
        if (IS_ADMIN) {
            require_once(WP_PLUGIN_DIR . '/' . basename(dirname(__FILE__)) . "/admin/index.php");
        }
        else {
            //If the frontend
            require_once(WP_PLUGIN_DIR . '/' . basename(dirname(__FILE__)) . "/frontend/index.php");
        }
    }

    public static function get($name, $array = null)
    {
        if (!$array)
            $array = $_GET;

        if (isset($array[$name]))
            return $array[$name];

        return "";
    }

    public static function post($name)
    {
        if (isset($_POST[$name]))
            return $_POST[$name];

        return "";
    }

    public static function is_uslider_ajax_action()
    {
        //Gravity Forms AJAX requests
        $current_action = self::post("action");
        $ajax_actions = array(
            "prime_ajax_get_attachment_meta_with_image",
            "adapUS_ajax_get_attachment_image_srcs");

        if (defined("DOING_AJAX") && DOING_AJAX && in_array($current_action, $ajax_actions))
            return true;

        //not a gravity forms ajax request.
        return false;
    }

    //Returns true if the current page is one of Gravity Forms pages. Returns false if not
    public static function is_uslider_page()
    {
        //Gravity Forms pages
        $current_page = trim(strtolower(self::get("page")));
        $pages = array("primeslider");

        return in_array($current_page, $pages);
    }

    public static function get_hash_of_slider_ids_and_titles()
    {
        $uslider_models = USlider::get_models();
        $hash = array();

        if (isset($uslider_models['prime-sb-sliders'])) {
            $sliders = $uslider_models['prime-sb-sliders'];
            foreach ($sliders as $s) {
                $title = $s['title'];
                $id = $s['id'];
                $hash[$id] = $title;
            }
        }

        return $hash;

    }

    public static function get_models()
    {
        return get_option(USLIDER_MODEL_WP_OPTION_NAME);
    }

    public static function get_slider_model($id)
    {
        $models = USlider::get_models();
        if (isset($models['prime-sb-sliders'])) {
            $sliders = $models['prime-sb-sliders'];
            if (isset($sliders[$id])) return $sliders[$id];
            else return null;
        }
    }


}