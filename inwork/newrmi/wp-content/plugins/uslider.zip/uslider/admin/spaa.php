<?php

/**
 * Abstract Base Class for Single Page Administrative Apps (SPAA)
 */
abstract class PrimeSinglePageApp
{
    public static $version = "0.0.0.1";

    protected $app_name;
    protected $app_options_key;

    protected $app_js_file_url;
    protected $app_js_file_slug;
    protected $app_additional_js_prereqs;

    protected $menu_page_title;
    protected $menu_menu_title;
    protected $menu_capability;
    protected $menu_slug;
    protected $main_callback;

    protected $app_ajax_save_model_action;

    /**
     * The Constructor for the SPAA
     */
    function __construct()
    {
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_menu', array($this, 'admin_menu'));

        $this->main_callback = array($this, 'render_admin_page');
    }

    function admin_init()
    {
        add_action('wp_ajax_' . $this->app_ajax_save_model_action, array($this, 'save_models'));

        $baseURL = USLIDER_ROOT_URI;
        /*
        * Backbone and its prequisites
        */
        wp_register_script('json2', $baseURL . 'js/json2.js', array(), false, true);

        /*
        * Backbone Plugins/Extensions
        */
        wp_register_script('backbone-localstorage', $baseURL . 'js/backbone.memstore.js',
            array('json2', 'backbone'), false, true);
        wp_register_script('backbone-relational', $baseURL . 'js/backbone-relational.js',
            array('json2', 'backbone'), false, true);

        wp_register_script('backbone-forms', $baseURL . 'js/backbone-forms/backbone-forms.min.js', array('json2', 'backbone'));
        wp_register_script('bff-twitter-bootstrap', $baseURL . 'js/backbone-forms/templates/bootstrap.js',
            array('backbone-forms'));

        wp_register_script('twitter-bootstrap', $baseURL . 'admin/js/bootstrap.min.js');

        wp_register_script('bootstrap-colorpicker', $baseURL . 'admin/js/colorpicker/js/bootstrap-colorpicker.js',
            array('jquery', 'twitter-bootstrap'), false, true);

        wp_register_style('bootstrap-colorpicker', $baseURL . 'admin/js/colorpicker/css/colorpicker.css',
            array('twitter-bootstrap'));

        wp_register_style('twitter-bootstrap', $baseURL . 'admin/css/bootstrap.css');
        wp_register_style('bff-twitter-bootstrap', $baseURL . 'js/backbone-forms/templates/bootstrap.css',
            array('twitter-bootstrap'));

        /*
        * Adaptive Themes developed JS
        */
        $prereqs = array('backbone', 'backbone-localstorage', 'jquery');
        $prereqs = array_merge($prereqs, $this->app_additional_js_prereqs);

        wp_register_script($this->app_js_file_slug, $this->app_js_file_url, $prereqs, false, true);
    }

    /**
     * Adds the menu item for the SPAA and also registers $this->admin_styles to fire when the page
     * for the SPAA is getting fired
     */
    function admin_menu()
    {
        $page = add_menu_page($this->menu_page_title, $this->menu_menu_title, $this->menu_capability, $this->menu_slug, $this->main_callback);
        add_action('admin_print_styles-' . $page, array($this, 'admin_styles'));
    }

    /**
     * Enqueues scripts and stylesheets for SPAA
     */
    function admin_styles()
    {
        wp_enqueue_script('jquery');
        wp_enqueue_script('underscore');
        wp_enqueue_script('json2');
        wp_enqueue_script('backbone');
        wp_enqueue_script('backbone-relational');
        wp_enqueue_script('backbone-localstorage');

        wp_enqueue_script('backbone-forms');
        wp_enqueue_script('bff-twitter-bootstrap');
        wp_enqueue_script('twitter-bootstrap');

        wp_enqueue_script('bootstrap-colorpicker');
        wp_enqueue_style('bootstrap-colorpicker');

        wp_enqueue_style('twitter-bootstrap');
        wp_enqueue_style('bff-twitter-bootstrap');

        $this->bootstrap_spaa_data();

        wp_enqueue_script($this->app_js_file_slug);
    }

    abstract function bootstrap_spaa_data();

    abstract function save_models();

    abstract function render_admin_page();

}