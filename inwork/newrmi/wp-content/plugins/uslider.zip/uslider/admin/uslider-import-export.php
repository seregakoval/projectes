<?php

/**
 * Abstract Base Class for Single Page Administrative Apps (SPAA)
 */

class USliderImportExportApp
{
    public static $version = "0.0.0.1";

    protected $app_name;
    protected $app_options_key;

    protected $app_js_file_url;
    protected $app_js_file_slug;
    protected $app_additional_js_prereqs;

    protected $menu_page_title;
    protected $menu_menu_title;
    protected $menu_capability;
    protected $menu_slug;
    protected $main_callback;

    protected $app_ajax_save_model_action;

    /**
     * The Constructor for the SPAA
     */
    function __construct()
    {
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_menu', array($this, 'admin_menu'));

        $this->main_callback = array($this, 'render_admin_page');

        $this->app_name = 'Slider Import/Export';
        $this->app_options_key = USLIDER_MODEL_WP_OPTION_NAME;

        $this->menu_page_title = 'Import/Export';
        $this->menu_menu_title = 'Import/Export';
        $this->menu_capability = 'edit_theme_options';
        $this->menu_slug = 'uslider-import-export';


        $this->app_js_file_url = USLIDER_ROOT_URI . '/admin/js/import-export-min.js';
        $this->app_js_file_slug = 'uslider-import-export';
        $this->app_additional_js_prereqs = array();
    }

    function admin_init()
    {
        add_action('wp_ajax_uslider_import_data',
            array($this, 'import_data'));

        $baseURL = USLIDER_ROOT_URI;
        /*
        * Backbone and its prequisites
        */
        wp_register_script('json2', $baseURL . 'js/json2.js', array(), false, true);

        /*
        * Adaptive Themes developed JS
        */
        $prereqs = array('backbone', 'jquery');
        $prereqs = array_merge($prereqs, $this->app_additional_js_prereqs);

        wp_register_script($this->app_js_file_slug, $this->app_js_file_url, $prereqs, false, true);
    }

    /**
     * Adds the menu item for the SPAA and also registers $this->admin_styles to fire when the page
     * for the SPAA is getting fired
     */
    function admin_menu()
    {
        $page = add_submenu_page('primeslider', $this->menu_page_title, $this->menu_menu_title, $this->menu_capability, $this->menu_slug, $this->main_callback);
        add_action('admin_print_styles-' . $page, array($this, 'admin_styles'));
    }

    /**
     * Enqueues scripts and stylesheets for SPAA
     */
    function admin_styles()
    {
        $baseURL = USLIDER_ROOT_URI;

        wp_enqueue_script('jquery');
        wp_enqueue_script('underscore');
        wp_enqueue_script('json2');
        wp_enqueue_script('backbone');

        wp_enqueue_script('twitter-bootstrap');
        wp_enqueue_style('twitter-bootstrap');

        wp_register_style('usliderAdmin', $baseURL . 'admin/css/admin.css');
        wp_enqueue_style('usliderAdmin');

        $this->bootstrap_spaa_data();

        wp_enqueue_script($this->app_js_file_slug);
    }

    function bootstrap_spaa_data()
    {
        $sliderModels = get_option(USLIDER_MODEL_WP_OPTION_NAME);
        $retIds = array();

        if (isset($sliderModels['prime-sb-slides'])) {
            $layers = &$sliderModels['prime-sb-slides'];

            foreach ($layers as $sid => &$s) {
                if (isset($s['background']) && isset($s['background']['image'])) {
                    $imgId = $s['background']['image'];
                    $s['background']['image'] = get_the_title($imgId);
                }
            }
        }

        if (isset($sliderModels['prime-sb-layouts'])) {
            $layers = &$sliderModels['prime-sb-layouts'];

            foreach ($layers as $sid => &$s) {
                if (isset($s['background']) && isset($s['background']['image'])) {
                    $imgId = $s['background']['image'];
                    $s['background']['image'] = get_the_title($imgId);
                }
            }
        }


        if (isset($sliderModels['prime-sb-layers'])) {
            $layers = &$sliderModels['prime-sb-layers'];

            foreach ($layers as $lid => &$l) {
                if ($l['type'] == 'mobileImage' || $l['type'] == 'desktopImage') {
                    if (isset($l['image'])) {
                        $imgId = $l['image'];

                        $l['image'] = get_the_title($imgId);
                    }
                }
            }
        }

        $data = base64_encode(serialize($sliderModels));

        wp_localize_script($this->app_js_file_slug,
            'usie_export_data', $data);
    }

    function import_data()
    {
        if (IS_ADMIN) {
            try {
                $sliderModels = unserialize(base64_decode($_POST['uslider_import_data']));

                if (isset($sliderModels['prime-sb-slides'])) {
                    $layers = &$sliderModels['prime-sb-slides'];

                    foreach ($layers as $sid => &$s) {
                        if (isset($s['background']) && isset($s['background']['image'])) {
                            $imgTitle = $s['background']['image'];
                            $s['background']['image'] = $this->getIDFromTitle($imgTitle);
                        }
                    }
                }

                if (isset($sliderModels['prime-sb-layouts'])) {
                    $layers = &$sliderModels['prime-sb-layouts'];

                    foreach ($layers as $sid => &$s) {
                        if (isset($s['background']) && isset($s['background']['image'])) {
                            $imgTitle = $s['background']['image'];
                            $s['background']['image'] = $this->getIDFromTitle($imgTitle);
                        }
                    }
                }

                if (isset($sliderModels['prime-sb-layers'])) {
                    $layers = &$sliderModels['prime-sb-layers'];

                    foreach ($layers as $lid => &$l) {
                        if ($l['type'] == 'mobileImage' || $l['type'] == 'desktopImage') {
                            if (isset($l['image'])) {
                                $imgTitle = $l['image'];

                                $l['image'] = $this->getIDFromTitle($imgTitle);
                            }
                        }
                    }
                }

                if (
                    isset($sliderModels['prime-sb-layers']) &&
                    isset($sliderModels['prime-sb-slides']) &&
                    isset($sliderModels['prime-sb-sliders']) &&
                    isset($sliderModels['prime-sb-layouts'])
                ) {
                    update_option(USLIDER_MODEL_WP_OPTION_NAME, $sliderModels);
                    die('success');
                }
                else {
                    die('malformed');
                }

            }
            catch (Exception $e) {
                die('Caught exception: ' . $e->getMessage());
            }
        }

        die('failure'); // this is required to return a proper result
    }

    function getIDFromTitle($title)
    {
        $the_post = get_page_by_title($title, 'OBJECT', 'attachment');
        if (isset($the_post->ID)) return $the_post->ID;
    }

    function render_admin_page()
    {
        ?>
    <h1>Import/Export</h1>
    <ul class="nav nav-tabs" id="myTab">
        <li class="active"><a href="#importContent">Import</a></li>
        <li><a href="#exportContent">Export</a></li>
    </ul>

    <div id="main-import-export" class="tab-content">

    </div>

    <script id="importTemplate" type="text/template">
        <textarea name="import_slider_data" rows="8" id="import_slider_data"
                  class="import_slider_data"></textarea>
        <p class="instructions">Paste in your uSlider export data above and click the "Import Button". <strong STYLE="color:red;">THIS WILL DELETE ANY PREEXISTING USLIDERS ON THIS SERVER AND REPLACE THEM WITH THE IMPORTED ONES.</strong> Also, please be sure that you've imported any images used via the standard WordPress import/export functionality.</p>
        <a class="btn btn-primary ob_button right import-data">Import Data</a>
    </script>

    <script id="exportTemplate" type="text/template">
        <textarea name="export_data" id="export_data"
                  rows="8" readonly="readonly"><%= data %></textarea>
        <p>Select and copy everything in the textarea above. Then copy it into the "Import" page of the uSlider installation you want to move your sliders to.</p>
    </script>

    <style>
        textarea {
            width: 90%;
            min-height: 300px;
        }

    </style>

    <script id="saveSuccessTemplate" type="text/template">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="myModalLabel">Import Successful</h3>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" data-dismiss="modal" aria-hidden="true">Close</button>
        </div>
    </script>

    <script id="saveFailureTemplate" type="text/template">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            <h3 class="myModalLabel">Whoops, something went wrong. The import could not be completed.</h3>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" data-dismiss="modal" aria-hidden="true">Close</button>
        </div>
    </script>

    <div class="modal hide fade" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
    </div>
    <?php
    }

}

$prime_slider_import_export_app = new USliderImportExportApp();