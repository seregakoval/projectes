<?php

class SliderBuilderAdminApp extends PrimeSinglePageApp
{

    /**
     * Instead of having a really robust list of arguments in the parent constructor,
     * we just do configuration via code. It's easier and clearer.
     */
    function __construct()
    {
        parent::__construct();

        $this->app_name = 'Slider Builder';
        $this->app_options_key = USLIDER_MODEL_WP_OPTION_NAME;

        $this->menu_page_title = 'uSlider Builder';
        $this->menu_menu_title = 'uSlider Builder';
        $this->menu_capability = 'edit_theme_options';
        $this->menu_slug = 'primeslider';


        $this->app_js_file_url = USLIDER_ROOT_URI. '/admin/js/prime-slider-min.js';
        $this->app_js_file_slug = 'prime-slider-builder';
        $this->app_additional_js_prereqs = array('jquery-ui-sortable', 'thickbox', 'uslider-models');

        /*
         * The action that should be provided to WP Ajax in order to save the models.
         * This action should be sent with the Post from prime-slider.js
         */
        $this->app_ajax_save_model_action = 'prime_slider_builder_save_models';

        add_filter('attachment_fields_to_edit', array($this, 'add_media_uploader_buttons'), 10, 2);

        //        add_action('uSliderContentRemoved', array($this, 'deregisterString'), 10, 2);
        //        add_action('uSliderContentAdded', array($this, 'registerString'),  10, 2);

    }

//    function deregisterString($title,$str)
//    {
//        icl_register_string('uSlider', $title, $str);
//    }
//
//    function registerString($title, $str)
//    {
//        icl_unregister_string('uSlider', $title);
//    }

    function admin_styles()
    {
        wp_enqueue_script('uslider-models', USLIDER_ROOT_URI . 'js/models-min.js', array('backbone', 'backbone-localstorage', 'jquery', 'backbone-relational', 'backbone-forms'));

        parent::admin_styles();

        wp_enqueue_style('thickbox');
        wp_enqueue_script('thickbox');
        wp_enqueue_script('media-upload');

        // Custom Slider Admin CSS
        wp_register_style('usliderAdmin', USLIDER_ROOT_URI . 'admin/css/admin.css', __FILE__);
        wp_enqueue_style('usliderAdmin');

        wp_enqueue_style('font-awesome', USLIDER_ROOT_URI . 'frontend/css/fonts.css');
    }


    function add_media_uploader_buttons($form_fields, $post)
    {
        $postId = isset($_GET['post_id']) ? $_GET['post_id'] : false;
        if ($postId === 0 || $postId == '0') {
            $label = __('Set Image');

            $form_fields['prime-sb-send-to-editor'] = array(
                'label' => '',
                'input' => 'html',
                'html' => '<a href="#" data-attachment-id="' . $post->ID . '" class="button prime_sb_send_to_field">' . $label . '</a>');
        }
        return $form_fields;
    }

    function bootstrap_spaa_data()
    {
        //        delete_option($this->app_options_key);
        //        wp_localize_script($this->app_js_file_slug, 'prime_sb_bootstrap_models', get_option($this->app_options_key));
        wp_localize_script('uslider-models', 'prime_sb_bootstrap_models', get_option($this->app_options_key));

    }

    function save_models()
    {
        if (IS_ADMIN) {
            $models = stripslashes($_POST['prime_sb_models']);
            $models = json_decode($models, true);

            ////            Logic to filter edited layers
            //            $layers = $models['prime-sb-layers'];
            //            $oldLayers = get_option($this->app_options_key, true);
            //            $oldLayers = $oldLayers['prime-sb-layers'];
            //
            //            foreach ($layers as $l) {
            //                if (isset($l['content'])) {
            //                    $layerID = $l['id'];
            //                    $newContent = $l['content'];
            //                    $registerNew = false;
            //
            //                    if (isset($oldLayers[$layerID])) {
            //                        $oldContent = $oldLayers[$layerID]['content'];
            //                        if ($newContent != $oldContent) {
            //                            //Deregister Old Content
            //                            do_action('uSliderContentRemoved', $oldLayers[$layerID]['title'], $oldContent);
            //                            $registerNew = true;
            //                        }
            //                    } else {
            //                        $registerNew = true;
            //                    }
            //
            //                    if ($registerNew) {
            //                        do_action('uSliderContentAdded', $l['title'], $newContent);
            //                    }
            //                }
            //            }
            //
            //            foreach ($oldLayers as $ol) {
            //                $oid = $ol['id'];
            //                if (isset($ol['content']) && !isset($layers[$oid])) {
            //                    do_action('uSliderContentRemoved', $ol['title'], $ol['content']);
            //                }
            //            }

            update_option($this->app_options_key, $models);

            die(1); // this is required to return a proper result
        }
    }

    function render_admin_page()
    {
        ?>
    <div class="uslider-admin-wrapper wrap">
        <div id="icon-options-general" class="icon32"><br></div>
        <h2>uSlider Editor
            <div id="sb-global-actions"></div>
        </h2>
        <hr>
        <h4>All Sliders</h4>

        <p>Below are all the uSliders that have been created. Click the edit button to the right to modify a given
            slider.</p>

        <div id="main-sb-app"></div>
        <div id="sb-app-actions"></div>
        <hr>
        <div id="main-details-sb-app"></div>


        <div class="modal hide fade" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
             aria-hidden="true">
        </div>

        <script id="sbGlobalActionsTemplate" type="text/template">
            <span>
                <input name="save" type="submit" class="sb-save-changes btn btn-success btn-large" id="publish"
                       tabindex="5"
                       accesskey="p"
                       value="Save All Changes to All Sliders">
                    </span>
        </script>

        <script id="sliderIndexActionsTemplate" type="text/template">
        <span>
            <a href="#" class="addSlider"><i class="icon-plus"></i>Add Slider</a>
        </span>
        </script>

        <script id="sliderDetailsActionsTemplate" type="text/template">
        <span>
            <a href="#" class="backToIndex">&laquo; Back To Index</a>
        </span>
        </script>

        <script id="slideIndexHeaderTemplate" type="text/template">
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th></th>
                <th></th>
            </tr>
        </script>

        <script id="sliderPreviewTemplate" type="text/template">
            <td class="title-entry"><%= title %></td>
            <td class="desc-entry"><%= description %></td>
            <td>
                <span> <a href="#slider/<%= id %>" class="details btn"><i class="icon-edit"></i> Edit</a></span>
            </td>
            <td>
                <span> <a href="#" class="delete btn btn-danger"><i class="icon-trash"></i>Delete</a></span>
            </td>
        </script>

        <script id="sliderDetailsTemplate" type="text/template">
            <h4 class="title-entry">Edit Slider &mdash; <%= title %>
            </h4>
            <ul class="nav nav-tabs" id="myTab">
                <li class="active"><a href="#sliderForm">General Info</a></li>
                <li><a href="#desktopLayout">Fullsize Layout Settings</a></li>
                <li><a href="#mobileLayout">Mobile Layout Settings</a></li>
            </ul>

            <div class="tab-content">
                <div id="sliderForm" class="sliderForm tab-pane active"></div>
                <div id="desktopLayout" class="desktopLayout tab-pane"></div>
                <div id="mobileLayout" class="mobileLayout tab-pane"></div>
            </div>
        </script>

        <script id="layoutTemplate" type="text/template">
            <div class="layout-options-form-wrapper"></div>
            <div class="slides-header">
                <h5 class="slide-header">Slides</h5>
                <a href="javascript:void(0)" class="addSlide btn btn-primary btn-small"><i class="icon-plus"></i>Add
                    Slide</a>
            </div>
            <div class="slides-wrapper tabbable tabs-left"></div>
        </script>

        <script id="sliderIndexTemplate" type="text/template">
            <ul class="nav nav-tabs">

            </ul>

            <div class="tab-content">

            </div>
        </script>

        <script id="slideNavTemplate" type="text/template">
            <a href="#<%= id %>" data-toggle="tab" class="slide-nav-entry"><%= title %></a>
        </script>

        <script id="slideTemplate" type="text/template">
            <div id="<%= id %>" class="tab-pane">
                <a href="#" class="delete-slide btn btn-danger btn-small" style="float:right;"><i
                    class="icon-trash"></i>Delete Slide</a>

                <div class="slide-options-form-wrapper"></div>
                <h5 class="layer-title">Layers</h5>

                <div class="layers-wrapper accordion"></div>
                <div class="add-layer-wrapper">
                    Choose layer type to add:&nbsp;
                    <select class="addLayerType">
                        <option value="Content">Content</option>
                        <option value="Image">Image</option>
                        <option value="Video">Video</option>
                    </select>
                    <a href="#" class="addLayer"><i class="icon-plus"></i>Add Layer</a>
                </div>
            </div>
        </script>

        <script id="layerTemplate" type="text/template">

            <div class="accordion-heading"><i class="icon-reorder"></i>
                <a class="accordion-toggle" data-toggle="collapse" data-parent="#<%= parentID %>" href="#ab-<%= id %>">
                    <%= title %>&nbsp;&nbsp;<i class="icon-caret-down"></i>
                    <a href="#" class="delete-layer">Delete</a>
                </a>
            </div>

            <div id="ab-<%= id %>" class="accordion-body collapse" data-parent="#<%= parentID %>">
                <div class="accordion-inner">


                    <div class="layer-options-form-wrapper"></div>
                </div>
            </div>

        </script>

        <script id="WPMediaTemplate" type="text/template">
            <h5 class="att-title"></h5>

            <div class="att-img-wrapper"></div>
            <a href="#" class="launch-media-selector">Choose Image</a>
            <a href="#" class="clear-value">Remove Image</a>
        </script>

        <script id="ColorPickerTemplate" type="text/template">
            <input type="text" class="span4 colorpicker" value="<%= color %>">
        </script>

        <script id="saveSuccessTemplate" type="text/template">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="myModalLabel">Changes Saved</h3>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-dismiss="modal" aria-hidden="true">Close</button>
            </div>
        </script>

        <script id="saveFailureTemplate" type="text/template">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="myModalLabel">Whoops, something went wrong. Changes not saved.</h3>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-dismiss="modal" aria-hidden="true">Close</button>
            </div>
        </script>
    </div>
    <?php

    }
}

$prime_slider_builder_app = new SliderBuilderAdminApp();