<?php

if (!function_exists('prime_ajax_get_attachment_meta')) {
    function prime_ajax_get_attachment_meta()
    {
        $attachment_id = (int)$_POST['attachment_id'];
        $attachment = get_post($attachment_id);
        die(json_encode($attachment));
    }

    add_action('wp_ajax_prime_ajax_get_attachment_meta', 'prime_ajax_get_attachment_meta');
}

if (!function_exists('prime_ajax_get_attachment_img')) {
    function prime_ajax_get_attachment_img()
    {
        $attachment_id = (int)$_POST['attachment_id'];
        $out = wp_get_attachment_image($attachment_id, array(100, 100));

        die($out);
    }

    add_action('wp_ajax_prime_ajax_get_attachment_img', 'prime_ajax_get_attachment_img');
}

if (!function_exists('prime_ajax_get_attachment_meta_with_image')) {
    function prime_ajax_get_attachment_meta_with_image()
    {
        $attachment_id = (int)$_POST['attachment_id'];
        $post_type = get_post_type($attachment_id);

        if ($post_type == 'attachment') {
            $attachment = get_post($attachment_id);
            $image = wp_get_attachment_image($attachment_id, array(266, 177));

            $hash = array(
                'meta' => $attachment,
                'image' => $image
            );
        }
        else {
            $hash = array(
                'meta' => null,
                'image' => ''
            );
        }

        die(json_encode($hash));
    }

    add_action('wp_ajax_prime_ajax_get_attachment_meta_with_image', 'prime_ajax_get_attachment_meta_with_image');

}

if (!function_exists('adapUS_ajax_get_attachment_image_srcs')) {
    function adapUS_ajax_get_attachment_image_srcs()
    {
        $attachment_ids = $_POST['attachment_ids'];
        $retHash = array();
        foreach ($attachment_ids as $id) {
            $retHash[$id] = wp_get_attachment_image_src($id, 'full');
        }
        die(json_encode($retHash));
    }

    add_action('wp_ajax_adapUS_ajax_get_attachment_image_srcs', 'adapUS_ajax_get_attachment_image_srcs');
    add_action('wp_ajax_nopriv_adapUS_ajax_get_attachment_image_srcs', 'adapUS_ajax_get_attachment_image_srcs');

}