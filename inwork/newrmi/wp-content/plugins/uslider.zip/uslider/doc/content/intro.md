# Introduction #
[tfprofile]: http://themeforest.net/user/adaptivethemes "ThemeForest Profile"

_Created on 10/30/2012 By Adaptive Themes_

[Follow us on ThemeForest][tfprofile]

This document details installation and usage of the _uSlider Plugin with the Pax WordPress Theme_. This is __the first place to look for help when you encounter issues__ using uSlider. If you have questions that are not addressed by this document, please refer to the [Support](/support.html) section of this document. Thanks so much!