# Notes on Internet Explorer

Because of various IE technical shortcomings, the following _behavior degradations occur_ when accessing the uSlider via Internet Explorer

* __IE8 and IE9__ do not support CSS3 animations, so layer animations are not displayed -- all defined content is treated as content without an animation specified (ie. will display with the rest of the slide).
* __IE10 doesn't support the conventional touch API__ and as a result, uSlider does not support IE10 touch swiping.