<style>
 img { width: auto\9;
         height: auto;
         max-width: 100%;
         vertical-align: middle;
         border: 0;
         -ms-interpolation-mode: bicubic;

           padding: 4px;
           background-color: #fff;
           border: 1px solid #ccc;
           border: 1px solid rgba(0, 0, 0, 0.2);
           -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
              -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                   box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
         }</style>

# Walkthrough: Define A Slider

1. Click uSlider Builder in WP-Admin Menu

    ![uSlider Builder](resources/defineASlider/1-menu-item.png)

    _uSlider Builder Menu Item_

2. Click "Add Slider" link

    ![Add Slider](resources/defineASlider/2-addSlider.png)

    _uSlider Builder slider lisiting_

3. "New Slider" will appear in the Slider Listing, and its details will appear below

    ![New Slider](resources/defineASlider/3-newSliderAdded.png)

    _Initial Slider Details_

4. Define the Fullsize Layout (_Mobile Fullsize Settings_ tab)
    1. The Fields under the "General Info" are just for administrative tracking of the slider definition and aren't rendered to the site visitor in anyway.
    2. __Add Slide__
        1. Click "Add Slide"

            ![Add Slide](resources/defineASlider/4-addSlide.png)

        2. __Add Layer__
            * __Content Layer__

                ![Add Content Layer](resources/defineASlider/5a-contentLayer.png)

                _Administrative panel for a Content Layer_

                1. Select "Content" in drop down next to the "+Add Layer" link
                2. Click "+Add Layer"
                3. Layer will be added to the accordion. Click the layer to expand.
                4. Specify the `Title` field. The `Title` value is used in the administrative interface to keep track of the layer
                5. Specify the `Position` field. The `Position` field allows the layer content to shifted in relation to the top-left point of the slide.
                5. Specify the `Animation` field. The `Animation` field provides a way of defining CSS3 animations on your content. You can select the animation type from the dropdown and modify delay, duration, and iterations of the animation.
                6. Specify the `Width` field. The width of the layer container is controlled by this field.
                7. Specify the `Content` field. The `Content` field takes in HTML markup and displays it in the layer.
            * __Image Layer__ -- The image layer has special preloading behavior that makes sure that images and the slider load smoothly. It is highly reccommemded that you use an image layer for any image that you choose to include in a slide.

                ![Add Image Layer](resources/defineASlider/5b-imageLayer.png)

                _Administrative panel for an Image Layer_

                1. Select "Image" in drop down next to the "+Add Layer" link
                2. Click "+Add Layer"
                3. Layer will be added to the accordion. Click the layer to expand.
                4. Specify the `Title` field. The `Title` value is used in the administrative interface to keep track of the layer
                5. Specify the `Position` field. The `Position` field allows the layer content to shifted in relation to the top-left point of the slide.
                5. Specify the `Animation` field. The `Animation` field provides a way of defining CSS3 animations on your content. You can select the animation type from the dropdown and modify delay, duration, and iterations of the animation.
                6. Click "Choose Image" under the `Image` field, and use the WordPress Media Popup in order to select the attachment you want to use as the display image.
                7. Set the `Size` field. This will determine the size of the image when it is displayed.
            * __Video__ -- The Video Layer support embedding __YouTube and Vimeo__ videos with synching of video play and slideshow play behavior.

                ![Add Video Layer](resources/defineASlider/5c-videoLayer.png)

                _Administrative panel for a Video Layer_

                1. Select "Video" in drop down next to the "+Add Layer" link
                2. Click "+Add Layer"
                3. Layer will be added to the accordion. Click the layer to expand.
                4. Specify the `Title` field. The `Title` value is used in the administrative interface to keep track of the layer
                5. Specify the `Position` field. The `Position` field allows the layer content to shifted in relation to the top-left point of the slide.
                6. Set the `Size` field. This will determine the size of the image when it is displayed.
                7. Set the `Embed URL` field. This will either be a YouTube url provided by the YouTube "Share" feature or a URL to a Vimeo video page.
    3. Save your changes to the sliders by clicking the big, green button reading "Save All Changes to All Sliders" at the top right of the page.

    ![Save Changes](resources/defineASlider/6-saveChanges.png)

    _Save all changes_

5. Repeat step 4 for the Mobile Layout (_Mobile Layout Settings_ tab)
6. Repeat steps 4 and 5 as needed to create the slider
