# WPML Integration

<div class="tip">
This implementation is based off the [WPML Guidance on Plugin Integration](http://wpml.org/documentation/support/translation-for-texts-by-other-plugins-and-themes/). __NOTE:__ The code provided here provides a basic and general outline for where and how to modify code in order to integrate uSlider with WPML -- any additional integration with WPML is the responsibility of the user as specified by our [Support Policy](support.html).
</div>

Take the following steps to integrate with WPML:

1. In the `uslider` directory in `wp-content/plugins`, navigate to `uslider/admin/uslider-admin.php`
2. Navigate to `uslider-admin.php line 35` and uncomment the code so it appears as:
        add_action('uSliderContentRemoved', array($this, 'deregisterString'), 10, 2);
        add_action('uSliderContentAdded', array($this, 'registerString'),  10, 2);

    This code registers handlers for the `uSliderContentRemoved` and `uSliderContentAdded` actions that will be called during model saving logic.
3. Navigate to `uslider-admin.php line 40` and uncomment the code so it appears as:
        function deregisterString($title,$str)
        {
            icl_register_string('uSlider', $title, $str);
        }

        function registerString($title, $str)
        {
            icl_unregister_string('uSlider', $title);
        }

    These handlers call the WPML methods `icl_register_string` and `icl_unregister_string` in order to register and unregister strings respectively.
4. Navigate to `uslider-admin.php line 97` and uncomment the code so it appears as:
        $layers = $models['prime-sb-layers'];
        $oldLayers = get_option($this->app_options_key, true);
        $oldLayers = $oldLayers['prime-sb-layers'];

        foreach ($layers as $l) {
            if (isset($l['content'])) {
                $layerID = $l['id'];
                $newContent = $l['content'];
                $registerNew = false;

                if (isset($oldLayers[$layerID])) {
                    $oldContent = $oldLayers[$layerID]['content'];
                    if ($newContent != $oldContent) {
                        //Deregister Old Content
                        do_action('uSliderContentRemoved', $oldLayers[$layerID]['title'], $oldContent);
                        $registerNew = true;
                    }
                } else {
                    $registerNew = true;
                }

                if ($registerNew) {
                    do_action('uSliderContentAdded', $l['title'], $newContent);
                }
            }
        }

        foreach ($oldLayers as $ol) {
            $oid = $ol['id'];
            if (isset($ol['content']) && !isset($layers[$oid])) {
                do_action('uSliderContentRemoved', $ol['title'], $ol['content']);
            }
        }

    This logic handles checking for updated content layer content. It approriately fires the `uSliderContentRemoved` and `uSlideContentAdded` actions so that the handlers we just registered can register and deregister the strings for translation.

5. In the `uslider` directory in `wp-content/plugins`, navigate to `uslider/frontend/index.php`
6. Navigate to `index.php line 154` and comment out the code so it appears:
        $cVal = ict_t('uSlider', $l['title']);
    This code calls WPML's `ict_t` function in order to translate the content before `do_shortcode` is called and the content is packaged to be sent to the client.