# Support
[forum]: https://wpadaptive.zendesk.com/home "Support Forum"

## Our Support Policy
 If you're having trouble getting setup, we'll do our best to answer your queries as soon as possible. The bulk of our team is based in the _US (EST)_ so please be aware of any time difference. Support covers getting _setup, trouble using any features, and bug fixes_. Regretfully we cannot provide support for modifications or 3rd party plugins and themes.

<div class="tip">
 __All support is provided through the Adaptive Themes Support Forums__. Emails, Themeforest comments, and all other forms of
 contact for __support will be referred to the support forum__. We typically respond within __48 hours (assuming it isn't the weekend or a holiday)__.
</div>

 [Visit our Support Forum][forum]

## Third Party Themes
The uSlider Plugin is _supported for usage with the Pax WordPress Theme only_. Unfortunately, __we cannot provide support for troubleshooting the uSlider Plugin used with 3rd party plugins or themes.__ With that said, we do provide a [walkthrough in this document detailing how to use the uSlider Plugin with a theme other than Pax](thirdPartyTheme.html) as a courtesy to our users.

## Third Party Plugins
__Third party plugin conflicts are by far the most common cause of unexpected behavior and issues__. Before reporting a bug, __please deactivate all your plugins and see if the issue still exists__. If the issue goes away, you can figure out which plugin caused the problem by activating them one at a time and seeing which one makes the issue come back. Unfortunately, __we cannot provide support for troubleshooting the uSlider Plugin used with conflicting 3rd party plugins or themes.__

## After Purchase Customization
Support covers setting up the plugin with Pax __but not support or guidance for plugin or theme code changes__. Users making code modifications to the plugin and/or theme should be able to navigate and understand code by themselves.