<style>
 img { width: auto\9;
         height: auto;
         max-width: 100%;
         vertical-align: middle;
         border: 0;
         -ms-interpolation-mode: bicubic;

           padding: 4px;
           background-color: #fff;
           border: 1px solid #ccc;
           border: 1px solid rgba(0, 0, 0, 0.2);
           -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
              -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                   box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
         }</style>

# Responsive Behavior

The __uSlider Plugin__ integrates with the __Pax WordPress Theme__. This integration means that uSlider adheres to the __two-layout (Fullsize/Mobile), responsive behavior__ that Pax implements. uSlider queries and listens for data and events from Pax in order to service the layout that is being currently displayed.

Fullsize _content and behaviors_ are __defined separately__ from the Mobile _content and behaviors_ for each slider. This allows you to tailor the slider experience optimally for different devices. For more details on how to define a slider, please refer to the [Defining A Slider Walkthrough](/defineSlider.html).

<div class="note">
__Third Party Theme Layout Behavior:__ uSlider respects whichever of the three layout modes Pax supports. However, when uSlider is used with a Third Party Theme (aka not Pax), uSlider switches between displaying the Fullsize slider and Mobile slider on the basis of the device width. For more information on uSlider integration with a third party theme, please refer to the [Third Party Theme Walkthrough](/thirdParty.html).
</div>

For more details on the responsive behavior of Pax, please refer to the __Pax WordPress Theme Documentation__.

# Slider Structure
The entity structure of a given Slider Definition is as follows:

* __Slider__
    * __Fullsize Layout__
        * __Slides__ _w/ click & drag ordering_
            * __Layers__ _w/ click & drag ordering_
    * __Mobile Layout__
        * __Slides__ _w/ click & drag ordering_
            * __Layers__ _w/ click & drag ordering_

![Slider Structure](resources/concepts/slider-structure-annotated.png)

_An annotated capture of the Fullsize layout in the uSlider Adminstrative Panel_
## Layouts
Every Slider Definition has two layouts. The two layouts service __Fullsize__ and __Mobile__ devices with different behavior and content. Each layout consists of its __general properties__ and an __ordered collection of slides__

1. _Fullsize Layout_ -- All the settings and content for defining the slider's display for the Fullsize Layout. This is the content that will be displayed on Fullsize and tablet devices.
    * _General Options_
    * _Slides_ _w/ click & drag ordering_
2. _Mobile Layout_ -- All the settings and content for defining the slider's display for the Mobile Layout. This is the content that will be displayed on mobile devices.
    * _General Options_
    * _Slides_ _w/ click & drag ordering_

![Fullsize Layout Interface](resources/concepts/dt-layout.png)

_The Fullsize layout in the uSlider Adminstrative Panel_

![Mobile Layout Interface](resources/concepts/mobile-layout.png)

_The Mobile layout in the uSlider Adminstrative Panel_

## Slides
Slides consist of:

* A __Title__ -- The title of the slide. This is _used administratively_ in order to differentiate between slides.
* A __Background__ -- The CSS background for the entire slide
* An __Ordered Collection of Layers__ -- Layers are the mechanism through which slide content is defined and organized.

Slides __appearance order__ can be modified by _clicking and dragging the tabs_ in a layout's slide listing.

![Slides Interface](resources/concepts/slide-index.png)

_The slides listing in the uSlider Administrative Panel_
## Layers
Layers are where all slide content gets defined. The z-index of the layers can be manipulated by clicking and dragging the __layer elements__ in the administrative interface. The earlier in the listing a layer appears, the higher its z-index is set. There are three types of layers for your convenience. All layer types have a _title_ field and a _position_ field. The title is used administratively, and the position field determines the position of the top-left of the layer.

### Content Layer
The content layer is used in order to include any HTML content as a layer. It supports the following fields in addition to title and position:

* __Animation__ - The specification for the animation behavior to apply to the layer
* __Width__ - How wide the layer should be
* __Content__ - The HTML Markup to use as the layer content.

![Content Layer](resources/concepts/content-layer.png)

_A Content Layer in the uSlider Adminstrative Panel_

### Image Layer
An image layer is used to include images that are nicely preloaded before the slider is displayed. The image selection is routed through the WordPress Media Management system. In addition to the title and positioning fields, the following settings are available on image layers:

* __Animation__ -- The specification for the animation behavior to apply to the layer
* __Image__ -- The WordPress image attachement to use as the image source
* __Size__ -- The dimensions of the image to display

![Image Layer](resources/concepts/image-layer.png)

_An Image Layer in the uSlider Adminstrative Panel_

### Video Layer
A video layer injects __YouTube or Vimeo videos__ (only) and takes care of special play/pause integration with the slideshow. It's important that if you want to use an embed video in the slider that you do it through the Video Layer mechanism. In addition to the title and position fields, the following settings are available on video layers:

* __Size__ -- The dimensions of the video
* __Embed URL__ -- The embed URL from YouTube or Vimeo

![Video Layer](resources/concepts/video-layer.png)

_A Video Layer in the uSlider Adminstrative Panel_
