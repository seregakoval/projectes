# Walkthrough: Using a Slider

1. Log into `WP-Admin`
2. Navigate to the `Edit Page` or `Edit Post` page associated with the page or post you want the slider to appear on.
3. Locate the __"uSlider Selection"__ metabox.
    <div class="tip">
    If you can't see the "uSlider Selection" metabox, click the __"Screen Options"__ tab at the top right of the panel. Make sure that the __"uSlider selection"__ checkbox is checked under __"Show on screen"__.
    </div>
4. In the dropdown in the "uSlider Selection" metabox, select the slider that you want to appear.
5. Click the blue __"Update/Publish"__ button to save you changes
6. The selected slider will now display on the site page/post.