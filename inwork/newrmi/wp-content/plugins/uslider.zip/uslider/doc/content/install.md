# Installation

##  Downloading the Theme Package ##
The __uSlider Plugin__ is packaged with the _Pax WordPress Theme_. To download the Pax WordPress Theme Package from ThemeForest, do the following:

1. In your browser, navigate to your _Account Dashboard_ in ThemeForest
2. Click on the _Downloads_ tab
3. Click the _Download_ button associated with _Pax_
4. Your browser will __download a zip package__.
5. Unzip the downloaded package.

## Installation ##

### Requirements ###
* __Pax WordPress Theme installed__. For more details on Pax, please refer to the Pax WordPress Theme Documentation.

Once you've downloaded the Pax WordPress Theme package from Themeforest, you can install the uSlider Plugin by doing the following:

1. Log into the _WordPress Administrative Dashboard_.
2. Navigate to `Plugins > Add New` via the admin menu.
3. Click the __"Upload"__ link at the top of the `Install Plugins` page
4. In the file upload field that appears, click the __"Choose File"__ button in order to launch a file picker.
5. In the file picker, navigate to where you unzipped the downloaded Pax WordPress Theme package.
6. Select the `{THEME_PACKAGE_UNZIPPED}/plugins/uslider.zip` file and click the __"Open"__ button in the file picker.
7. The file picker will close.
8. Click the __"Install Now"__ button.
9. Once WordPress is done installing the plugin, click the __"Activate Plugin"__ link that appears to activate the uSlider Plugin.
10. The uSlider Plugin is now installed and activated.
