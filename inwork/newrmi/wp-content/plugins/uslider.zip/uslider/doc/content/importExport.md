# Export
uSlider's export functionality allows you to export all the sliders on the system. Do the following to export all the slider data on your WordPress installation:

1. Click _uSlider Builder > Import/Export_ in the WP-Admin menu
2. Navigate to the __"Export"__ tab
3. Select all the content of the textbox
4. Copy the contents to a __new, blank text file__ and save that file with a descriptive title
5. Your content has now been exported

<div class="tip">
uSlider refers to _background images_ and _image layer_ images by references to wp-attachments. When exporting a slider, if you are using a background image or image layer in the slider, you will need to also export the media from you installation using the [WP-Importer/Exporter](http://codex.wordpress.org/Importing_Content#WordPress "WP-Importer"). During import, uSlider will look for an attachment with a file name that matches that of the old attachments filename.
</div>

# Import

<div class="warning">
__WARNING:__ Running import will __OVERWRITE__ your installation's current slider definitions. uSlider only supports wholesale replacement of slider definitions. __DO NOT__ run import if you need to maintain the sliders that are currently definied in your destination WP installation.
</div>

<div class="tip">
 During import, uSlider will look for an attachment on the destination install with a file name that matches that of the old attachment filename. If the attachment is found, the reference will be imported correctly. If the attachment is not found, then the image field will come up as blank in the uSlider builder. __Run [WP-Importer/Exporter](http://codex.wordpress.org/Importing_Content#WordPress "WP-Importer") Content Import BEFORE running the uSlider Import__; if you don't, the image fields will not import correctly.
</div>

1. Click _uSlider Builder > Import/Export_ in the WP-Admin menu
2. Navigate to the __"Import"__ tab
3. Copy and Paste all the text from your export file into the textbox
4. Click the "Import Data" button
5. Wait for a feedback popup to know that the import has completed

# Demo Data

1. In the theme download package, locate the `resources` folder and locate `slider.txt` inside that folder.
2. Follow the [import instructions](importexport.html) using the `slider.txt` file.
3. Use the uSlider Builder to view available sliders and select the desired slider on a given page or post.