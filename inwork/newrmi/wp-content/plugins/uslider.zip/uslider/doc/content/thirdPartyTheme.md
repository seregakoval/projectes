# Third Party Themes

<div class="warning">
The uSlider Plugin is _supported for usage with the Pax WordPress Theme only_. Unfortunately, __we cannot provide support for troubleshooting the uSlider Plugin used with 3rd party plugins or themes.__ With that said, we do provide a walkthrough in this document detailing how to use the uSlider Plugin with a theme other than Pax as a courtesy to our users.
</div>

## Example Usage w/ Twenty Twelve

__Twenty Twelve__ is the _default WordPress Theme_. Here we list the steps to take in order to use the uSlider Plugin with Twenty Twelve.

1. [Install uSlider](install.html)
2. Locate your Twenty Twelve theme on your filesystem. It will probably be located in `wp-content/themes/twentytwelve` starting from you WordPress installation root.
3. Locate the file `twentytwelve/header.php`
4. At the bottom of the file, place the following
        <?php
            do_action('uslider');
        ?>
    <div class="tip">
    The action trigger `do_action('uslider')` kicks of uSlider rendering in the site frontend. If you want uSlider to appear somewhere other than the top of the `div.main`, __you can trigger the action elsewhere in your theme templates__.
    </div>
5. Save `twentytwelve/header.php`
6. __Utilize the uSlider plugin__ _as described in this documentation_ with the Twenty Twelve theme after taking these steps.