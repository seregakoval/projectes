<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Hiron
 * Date: 9/26/12
 * Time: 1:28 PM
 * To change this template use File | Settings | File Templates.
 */
class PrimePluginCommon
{
    public static $version = "0.0.0.1";

    //Returns the url of the plugin's root folder
    public static function get_base_url()
    {
        $folder = basename(dirname(__FILE__));
        return plugins_url($folder);
    }

    //Returns the physical path of the plugin's root folder
    public static function get_base_path()
    {
        $folder = basename(dirname(__FILE__));
        return WP_PLUGIN_DIR . "/" . $folder;
    }

    public static function getSliderAttIDs()
    {
        $sliderModels = get_option(USLIDER_MODEL_WP_OPTION_NAME);
        $retIds = array();
        if (isset($sliderModels['prime-sb-slides'])) {
            $layers = $sliderModels['prime-sb-slides'];

            foreach ($layers as $sid => $s) {
                if (isset($s['background']) && isset($s['background']['image'])) {
                    $retIds[] = $s['background']['image'];
                }
            }
        }


        if (isset($sliderModels['prime-sb-layers'])) {
            $layers = $sliderModels['prime-sb-layers'];

            foreach ($layers as $lid => $l) {
                if ($l['type'] == 'mobileImage' || $l['type'] == 'desktopImage') {
                    $retIds[] = $l['image'];
                }
            }
        }

        if (isset($sliderModels['prime-sb-layouts'])) {
            $layouts = $sliderModels['prime-sb-layouts'];

            foreach ($layouts as $loid => $lo) {
                if (isset($lo['background']) && isset($lo['background']['image'])) {
                    $retIds[] = $lo['background']['image'];
                }
            }
        }

        return $retIds;

    }
}
