<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'SU5QCBXCR753YWuf27gYSlT44XZTAa7g',
            'baseUrl' => '/backend',
        ],
    ],
];

return $config;
