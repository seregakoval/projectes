<?php
namespace api\versions\v1\controllers;

use Yii;
use common\overrides\rest\ActiveController;

class SettingsController extends ActiveController
{
    public $modelClass = User::class;
    
    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [];
    }
    
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return \yii\helpers\ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['index'], // pass authorization
            ],
            'access' => [
                'class' => \yii\filters\AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['index'],
                        'roles' => ['?'],
                    ]
                ],
            ],
        ]);
    }
    
    /**
     * Settings for current rest module (v1)
     * @return array
     */
    public function actionIndex()
    {
        return [
            'apiversion' => $this->module->apiversion,
        ];
    }
}
