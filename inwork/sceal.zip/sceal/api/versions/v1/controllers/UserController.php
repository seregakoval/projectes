<?php
namespace api\versions\v1\controllers;

use Yii;
use yii\helpers\ArrayHelper;
use yii\filters\AccessControl;
use frontend\models\SignupForm;
use common\models\LoginForm;
use common\overrides\rest\ActiveController;
use api\versions\v1\models\User;
use api\versions\v1\controllers\user\RegistrationAction;
use api\versions\v1\controllers\user\LoginAction;
use api\versions\v1\controllers\user\DeleteAction;

/**
 * Class UserController
 * 
 * Display the users list.
 * GET api/v1/users
 * 
 * Display the user with id=1.
 * GET api/v1/users/1
 * 
 * Create new user using frontend SignupForm model.
 * POST api/v1/users/1
 * {
 *   'username': 'test',
 *   'password': '1111',
 *   'email': 'test@example.com'
 * }
 * 
 * Login user action using LoginForm model.
 * POST api/v1/users/1
 * {
 *   'username': 'test',
 *   'password': '1111'
 * }
 * 
 * @package api\versions\v1\controllers
 */
class UserController extends ActiveController
{
    public $modelClass = User::class;
    
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'authenticator' => [
                'except' => ['create', 'login'], // pass authorization
            ],
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['create', 'login'],
                        'roles' => ['?'],
                    ],
                    [
                        'allow' => true,
                        'actions' => ['index', 'view', 'update', 'delete', 'current'],
                        'roles' => ['@'],
                    ],
                ],
            ],
        ]);
    }
    
    public function actions()
    {
        return ArrayHelper::merge(parent::actions(), [
            // Create new user action using frontend SignupForm model.
            'create' => [
                'class' => RegistrationAction::class,
                'modelClass' => SignupForm::class,
            ],
            // Login user action using LoginForm model.
            'login' => [
                'class' => LoginAction::class,
                'modelClass' => LoginForm::class,
            ],
            // Delete user action.
            'delete' => [
                'class' => DeleteAction::class,
            ],
        ]);
    }
    
    public function actionCurrent()
    {
        return Yii::$app->user->identity;
    }
}
