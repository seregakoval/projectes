GBKSoft Yii 2 Advanced Project Template
===============================

Based on Yii 2 Advanced Project Template [Yii 2](http://www.yiiframework.com/)

The template includes four tiers: 
- api
- frontend
- backend
- console
Each of them is a separate Yii application.

ENVIRONMENTS
-------------------

The template is designed to work in a team development environment. It supports
deploying the application in different environments.
- Development       For developers and slicers - project.dev.gbksoft.net, project.fio.gbksoft.net and localhost
- Test              For tester - project.test.gbksoft.net    
- Live              For manager and customer - project.test.gbksoft.net
- Production        For production website (on customer's server)

ENVIRONMENTS INSTRUCTION
-------------------

Configuration and parameters values required for any possible environment 
should be placed into config folder outside environments.
/common/config              Values required for any environement and any application
/frontend/common/config     Values required for any environement and Frontend application
/backend/common/config      Values required for any environement and Backend application
/api/common/config          Values required for any environement and Api application
/console/common/config      Values required for any environement and Console application

Configuration and parameters values required for Development only should be placed
into config folder in environments/dev folder.
/environments/dev/common/config         Values required for Development environment and any application
/environments/dev/frontend/config       Values required for Development environment and Frontend application
/environments/dev/backend/config       Values required for Development environment and Backend application
/environments/dev/api/config       Values required for Development environment and Api application
/environments/dev/console/config       Values required for Development environment and Console application

DIRECTORY STRUCTURE
-------------------

```
common
    config/              contains shared configurations
    mail/                contains view files for e-mails
    models/              contains model classes used in both backend and frontend
console
    config/              contains console configurations
    controllers/         contains console controllers (commands)
    migrations/          contains database migrations
    models/              contains console-specific model classes
    runtime/             contains files generated during runtime
backend
    assets/              contains application assets such as JavaScript and CSS
    config/              contains backend configurations
    controllers/         contains Web controller classes
    models/              contains backend-specific model classes
    runtime/             contains files generated during runtime
    views/               contains view files for the Web application
    web/                 contains the entry script and Web resources
frontend
    assets/              contains application assets such as JavaScript and CSS
    config/              contains frontend configurations
    controllers/         contains Web controller classes
    models/              contains frontend-specific model classes
    runtime/             contains files generated during runtime
    views/               contains view files for the Web application
    web/                 contains the entry script and Web resources
    widgets/             contains frontend widgets
vendor/                  contains dependent 3rd-party packages
environments/            contains environment-based overrides
tests                    contains various tests for the advanced application
    codeception/         contains tests developed with Codeception PHP Testing Framework
```

CONFIG FILES ORDERING
-------------------
(APP stands for current application folder like backend, frontend, etc.)

```
common/config/main.php              Main config file. Contains all config data required everywhere.
common/config/main-local.php        Main config file from current environment.
common/config/dev.php               Development config file. Not added to git. Each developer has own one.
APP/config/main.php                 Application main config file.
APP/config/main-local.php           Application main config file from current environment.
APP/config/dev.php                  Application development config file. Not added to git. Each developer can have own one.
```


Development config files
-------------------

dev.php file can be placed into common/config or any application config folder. 
Any config changes can be made there required for current developer.
Basically it can be used to override development DB config data.
