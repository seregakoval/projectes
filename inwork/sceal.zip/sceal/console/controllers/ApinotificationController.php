<?php
namespace console\controllers;

use Yii;

/**
 * Cron job script
 * Notify clients about API changes
 * v0.0.8
 * @copyright (c) 2016, GBKSOFT
 *
 */
class ApinotificationController extends \yii\console\Controller
{
    const LOG_CATEGORY = 'apinotification';
    
    // URLs need to be watched
    private $urls = [
        'local URL' => [], // no tests
        'dev URL' => ['env'=>'dev'], // tests with --env dev
        'live URL' => ['env'=>'live'], // tests with --env live
        'staging URL'=>['env'=>'staging'], // tests with --env staging
        //example:
        //'http://fitnessapp.dev.gbksoft.net' => ['env'=>'dev'],
        //'http://fitnessapp.live.gbksoft.net' => ['env'=>'live'],
        //'http://staging.gymgo.com'=>['env'=>'staging'],
    ];
    
    private $apiVersionURL = '/api/v1/settings';
    
    // 1 - API URL domain
    // 2 - API version
    private $htmlReportURL = 'Watch api version URL /reports/%1$s/%2$s/report.html';
    private $htmlReportDebugURL = 'Watch api version DEBUG URL /reports/%1$s/%2$s/report.debug.log';
    // example: 
    //private $htmlReportURL = 'http://fitnessapp.dpp.gbksoft.net/reports/%1$s/%2$s/report.html';
    //private $htmlReportDebugURL = 'http://fitnessapp.dpp.gbksoft.net/reports/%1$s/%2$s/report.debug.log';
    
    // If tests need to be executed
    private $isRunTests = true;
    
    private $emailFrom = 'FROM email project group email';
    private $emailTo = 'TO email project group email eg. project+apinotification@';
    //example:
    //private $emailFrom = 'gymgowebdev@gmail.com';
    //private $emailTo = 'gymgoweb+apihistory@gbksoft.com';
    
    private $emailTransport = [
        'class' => 'Swift_SmtpTransport',
        'host' => 'smtp.gmail.com',
        'username' => '', // REQUIRED!
        'password' => '', // REQUIRED!
        'port' => '587',
        'encryption' => 'tls',
    ];
    
    public function actionCheck()
    {
        $this->log('start script');
        $this->log('Urls: '. print_r($this->urls, true));
        foreach ($this->urls as $url => $params) {
            $this->log('check url: '. $url);
            $this->checkApiUrl($url);
        }
        $this->log('end script');
    }

    public function actionReset()
    {
        foreach ($this->urls as $url => $params) {
            $this->setApiVersionByUrl($url, null);
        }
        
    }
    
    private function checkApiUrl($url)
    {
        $versionCurrent = $this->getApiVersionByUrl($url);
        
        if (empty($versionCurrent)) {
            $this->log("Can't get current version.");
            return;
        }
        $this->log('Current version: '. $versionCurrent);
        
        $versionPrev = $this->getPrevApiVersionByUrl($url);
        $this->log('Prev version: '. $versionPrev);
        
        // check if version has been changed
        if ($versionCurrent === $versionPrev) {
            // nothing has to be done
            $this->log('Prev version === current version.');
            return;
        }
        
        $this->log('Prev version != current version.');
        
        //run tests
        if ($this->isRunTests) {
            $this->runTests($url, $versionCurrent);
        }
        
        // notify
        if ($this->notifyByUrl($url, $versionPrev, $versionCurrent)) {
            $this->setApiVersionByUrl($url, $versionCurrent);
        }
    }
    
    private function notifyByUrl($url, $prev, $new)
    {
        $this->log('Send email notification');
        $body = "New API version was detected on the URL<br /><a href=\"{$url}\">{$url}</a>.<br />";
        $body .= "Current version: {$new}<br />";
        if (!empty($prev)) {
            $body .= "Previous version: {$prev}<br />";
        }
        
        // Add tests results to body
        if ($this->isRunTests) {
            $tapfile = $this->getTestsTapFileByUrl($url, $new);
            $reportUrl = $this->getTestsHTMLReportFileByUrl($url, $new);
            $reportDebugUrl = $this->getTestsHTMLReportDebugFileByUrl($url, $new);

            $tapfile_content = file_get_contents($tapfile);

            $body .= "<br /><br />".nl2br($tapfile_content) ."<br /><br />";
            $body .= "See full HTML report <a href=\"{$reportUrl}\">here</a> and debug <a href=\"{$reportDebugUrl}\">here</a><br />";
        }
        
        Yii::$app->mailer->setTransport($this->emailTransport);
        return Yii::$app->mailer->compose()
            ->setFrom($this->emailFrom)
            ->setTo($this->emailTo)
            ->setSubject("New api version ({$new}) on {$url}")
            ->setHtmlBody($body)
            ->send();
    }
    
    private function getApiVersionByUrl($url)
    {
        $json = null;
        try {
            $json = file_get_contents($this->apiEndPoint($url));
        } catch (yii\base\ErrorException $ex) {
            Yii::error("Can't connect to {$url}", self::LOG_CATEGORY);
        }
        
        if (empty($json)) {
            Yii::error("Empty json response", self::LOG_CATEGORY);
            return false;
        }
        
        $response = json_decode($json);
        if (!is_object($response)) {
            Yii::error("Can't decode json object", self::LOG_CATEGORY);
            return false;
        }

        if (!isset($response->result) or !isset($response->result->apiversion)) {
            Yii::error("Not valid response object: `". print_r($response, true) ."`", self::LOG_CATEGORY);
            return false;
        }
        
        $version = $response->result->apiversion;
        if (empty($version) or preg_match("/[0-9]+\.[0-9]+\.[0-9]+/", $version) !== 1) {
            Yii::error("Not valid version number: `{$version}`", self::LOG_CATEGORY);
            return false;
        }
        return $version;
    }
    
    private function setApiVersionByUrl($url, $version)
    {
        $this->log("Set api version to `{$version}` for url `{$url}`");
        return Yii::$app->cache->set($url, $version);
    }
    
    private function getPrevApiVersionByUrl($url)
    {
        return Yii::$app->cache->get($url);
    }
    
    
    private function apiEndPoint($url)
    {
        return $url.$this->apiVersionURL;
    }
    
    private function runTests($url, $apiversion)
    {
        $this->log("Run tests on url {$url}");
        
        $cmd = "cd ". dirname(__DIR__) ." && git pull -q origin master";
        passthru($cmd, $returnResult);
        $this->log("Execute command: {$cmd}; result: {$returnResult}");
        
        $env = $this->getTestsEnvByUrl($url);
        $testsPath = $this->getTestsDirPath();
        
        // create output folder
        $_output = $this->getTestsOutputDir($url, $apiversion);
        if (!file_exists($_output)) {
            mkdir($_output, 0775, true);
        }
        
        $reportHTML = $_output . "/report.html";
        $reportTap = $_output . "/report.tap.log";
        $reportDebug = $_output . "/report.debug.log";
        $cmd = "cd {$testsPath} && ../../../vendor/bin/codecept run api {$env} --no-interaction --html={$reportHTML} --tap={$reportTap} -vvv --no-colors --no-ansi 2>&1 >{$reportDebug} ";
        passthru($cmd, $returnResult);
        $this->log("Execute command: {$cmd}; result: {$returnResult}");
    }
    
    private function getTestsEnvByUrl($url)
    {
        if (isset($this->urls[$url]['env']) && !empty($this->urls[$url]['env'])) {
            return '--env '.$this->urls[$url]['env'];
        }
        $this->log("Empty environment for `{$url}`");
        return false;
    }
    
    private function getTestsTapFileByUrl($url, $apiversion)
    {
        $file = $this->getTestsOutputDir($url, $apiversion)."/report.tap.log";
        return $file;
    }
    
    /**
     * Return HTML report URL
     * @param string $url
     * @param string $apiversion
     * @return string URL
     */
    private function getTestsHTMLReportFileByUrl($url, $apiversion)
    {
        $domain = parse_url($url, PHP_URL_HOST);
        $file = sprintf($this->htmlReportURL, $domain, $apiversion);
        return $file;
    }
    
    /**
     * Return HTML DEBUG report URL
     * @param string $url
     * @param string $apiversion
     * @return string URL
     */
    private function getTestsHTMLReportDebugFileByUrl($url, $apiversion)
    {
        $domain = parse_url($url, PHP_URL_HOST);
        $file = sprintf($this->htmlReportDebugURL, $domain, $apiversion);
        return $file;
    }
    
    /**
     * Without trailing slash
     * @param string $url
     * @param string $apiversion
     * @return string path
     */
    private function getTestsOutputDir($url, $apiversion)
    {
        $domain = parse_url($url, PHP_URL_HOST);
        return $this->getTestsDirPath()."/tests/_output/{$domain}/{$apiversion}";
    }
    
    /**
     * Without trailing slash
     * @return string path
     */
    private function getTestsDirPath()
    {
        return realpath(dirname(__DIR__).'/../tests/codeception/api');
    }
    
    /**
     * Log info message
     * @param string $message
     */
    private function log($message)
    {
        Yii::info($message, self::LOG_CATEGORY);
    }
}
