<?php

use yii\db\Migration;
use common\models\User;
use common\models\Company;

class m160913_074039_alter_user_company extends Migration
{
    public function up()
    {
        // Alter user table, add columns
        $this->addColumn(User::tableName(), 'first_name', $this->string());
        $this->addColumn(User::tableName(), 'last_name', $this->string());
        $this->addColumn(User::tableName(), 'initials', $this->string());
        $this->addColumn(User::tableName(), 'email_secondary', $this->string());
        $this->addColumn(User::tableName(), 'phone_number', $this->string());
        $this->addColumn(User::tableName(), 'mobile_number', $this->string());
        $this->addColumn(User::tableName(), 'fax_number', $this->string());
        $this->addColumn(User::tableName(), 'contact_number', $this->string());
        $this->addColumn(User::tableName(), 'address', $this->string());
        $this->addColumn(User::tableName(), 'address2', $this->string());
        $this->addColumn(User::tableName(), 'goal', $this->text());
        $this->addColumn(User::tableName(), 'creator_id', $this->integer());
        $this->createIndex('i_creator_id', User::tableName(), 'creator_id');
        $this->addForeignKey('fk_user_creator', User::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Alter company table, add columns
        $this->addColumn(Company::tableName(), 'email_secondary', $this->string());
        $this->addColumn(Company::tableName(), 'phone_number', $this->string());
        $this->addColumn(Company::tableName(), 'mobile_number', $this->string());
        $this->addColumn(Company::tableName(), 'fax_number', $this->string());
        $this->addColumn(Company::tableName(), 'contact_number', $this->string());
        $this->addColumn(Company::tableName(), 'address', $this->string());
        $this->addColumn(Company::tableName(), 'address2', $this->string());
        $this->addColumn(Company::tableName(), 'goal', $this->text());
    }

    public function down()
    {
        // Alter company table, drop columns
        $this->dropColumn(Company::tableName(), 'email_secondary');
        $this->dropColumn(Company::tableName(), 'phone_number');
        $this->dropColumn(Company::tableName(), 'mobile_number');
        $this->dropColumn(Company::tableName(), 'fax_number');
        $this->dropColumn(Company::tableName(), 'contact_number');
        $this->dropColumn(Company::tableName(), 'address');
        $this->dropColumn(Company::tableName(), 'address2');
        $this->dropColumn(Company::tableName(), 'goal');

        // Alter user table, drop columns
        $this->dropForeignKey('fk_user_creator', User::tableName());
        $this->dropColumn(User::tableName(), 'first_name');
        $this->dropColumn(User::tableName(), 'last_name');
        $this->dropColumn(User::tableName(), 'initials');
        $this->dropColumn(User::tableName(), 'email_secondary');
        $this->dropColumn(User::tableName(), 'phone_number');
        $this->dropColumn(User::tableName(), 'mobile_number');
        $this->dropColumn(User::tableName(), 'fax_number');
        $this->dropColumn(User::tableName(), 'contact_number');
        $this->dropColumn(User::tableName(), 'address');
        $this->dropColumn(User::tableName(), 'address2');
        $this->dropColumn(User::tableName(), 'goal');
        $this->dropColumn(User::tableName(), 'creator_id');
    }
}
