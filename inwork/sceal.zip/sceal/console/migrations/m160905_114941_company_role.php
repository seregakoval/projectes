<?php

use yii\db\Migration;
use common\models\User;
use common\models\Company;
use common\models\CompanyUser;
use common\models\Role;
use common\models\RolePermission;
use common\models\Permission;

class m160905_114941_company_role extends Migration
{
    public function up()
    {
        $options = null;
        if ($this->db->driverName === 'mysql') {
            $options = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        // Create company table
        $this->createTable(Company::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(),
            'type'          => Company::getEnumForType(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', Company::tableName(), 'creator_id');
        $this->addForeignKey('fk_company_creator', Company::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create company_user table
        $this->createTable(CompanyUser::tableName(), [
            'company_id'    => $this->integer(),
            'user_id'       => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_company_user', CompanyUser::tableName(), ['company_id', 'user_id']);
        $this->createIndex('u_user_company', CompanyUser::tableName(), ['user_id', 'company_id'], true);
        $this->addForeignKey('fk_company_user_company', CompanyUser::tableName(), 'company_id', Company::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_company_user_user', CompanyUser::tableName(), 'user_id', User::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Create role table
        $this->createTable(Role::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(255),
            'description'   => $this->text(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', Role::tableName(), 'creator_id');
        $this->addForeignKey('fk_role_creator', Role::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create role_permission
        $this->createTable(RolePermission::tableName(), [
            'role_id'       => $this->integer(),
            'permission_id' => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_role_permission', RolePermission::tableName(), ['role_id', 'permission_id']);
        $this->createIndex('u_permission_role', RolePermission::tableName(), ['permission_id', 'role_id'], true);
        $this->addForeignKey('fk_role_permission_role', RolePermission::tableName(), 'role_id', Role::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_role_permission_permission', RolePermission::tableName(), 'permission_id', Permission::tableName(), 'id', 'CASCADE', 'CASCADE');
    }

    public function down()
    {
        // Drop role_permission
        $this->dropForeignKey('fk_role_permission_role', RolePermission::tableName());
        $this->dropForeignKey('fk_role_permission_permission', RolePermission::tableName());
        $this->dropTable(RolePermission::tableName());

        // Drop role table
        $this->dropForeignKey('fk_role_creator', Role::tableName());
        $this->dropTable(Role::tableName());

        // Drop company_user table
        $this->dropForeignKey('fk_company_user_company', CompanyUser::tableName());
        $this->dropForeignKey('fk_company_user_user', CompanyUser::tableName());
        $this->dropTable(CompanyUser::tableName());

        // Drop company table
        $this->dropForeignKey('fk_company_creator', Company::tableName());
        $this->dropTable(Company::tableName());
    }
}
