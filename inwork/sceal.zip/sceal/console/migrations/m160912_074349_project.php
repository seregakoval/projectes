<?php

use yii\db\Migration;
use common\models\User;
use common\models\Project;
use common\models\Report;
use common\models\ReportUser;
use common\models\Role;
use common\models\ProjectReport;
use common\models\Comment;
use common\models\Chat;

class m160912_074349_project extends Migration
{
    public function up()
    {
        $options = null;
        if ($this->db->driverName === 'mysql') {
            $options = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        // Create project table
        $this->createTable(Project::tableName(), [
            'id'            => $this->primaryKey(),
            'parent_id'     => $this->integer(),
            'creator_id'    => $this->integer(),
            'name'          => $this->string(),
            'description'   => $this->string(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', Project::tableName(), 'creator_id');
        $this->addForeignKey('fk_project_creator', Project::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');
        $this->createIndex('i_parent_id', Project::tableName(), 'parent_id');
        $this->addForeignKey('fk_project_parent', Project::tableName(), 'parent_id', Project::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create report table
        $this->createTable(Report::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(),
            'description'   => $this->text(),
            'due_date'      => $this->date(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', Report::tableName(), 'creator_id');
        $this->addForeignKey('fk_report_creator', Report::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create report_user table
        $this->createTable(ReportUser::tableName(), [
            'report_id'     => $this->integer(),
            'user_id'       => $this->integer(),
            'role_id'       => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_report_user', ReportUser::tableName(), ['report_id', 'user_id']);
        $this->createIndex('u_user_report', ReportUser::tableName(), ['user_id', 'report_id'], true);
        $this->addForeignKey('fk_report_user_report', ReportUser::tableName(), 'report_id', Report::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_report_user_user', ReportUser::tableName(), 'user_id', User::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->createIndex('i_report_user', ReportUser::tableName(), 'role_id');
        $this->addForeignKey('fk_report_user_role', ReportUser::tableName(), 'role_id', Role::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Create project_report table
        $this->createTable(ProjectReport::tableName(), [
            'project_id'    => $this->integer(),
            'report_id'     => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_project_report', ProjectReport::tableName(), ['project_id', 'report_id']);
        $this->createIndex('u_report_project', ProjectReport::tableName(), ['report_id', 'project_id'], true);
        $this->addForeignKey('fk_project_report_project', ProjectReport::tableName(), 'project_id', Project::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_project_report_report', ProjectReport::tableName(), 'report_id', Report::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Alter comment table, add chat_id
        $this->addColumn(Comment::tableName(), 'chat_id', $this->integer()->after('id'));
        $this->createIndex('i_chat_id', Comment::tableName(), 'chat_id');
        $this->addForeignKey('fk_comment_chat', Comment::tableName(), 'chat_id', Chat::tableName(), 'id', 'CASCADE', 'CASCADE');
    }

    public function down()
    {
        // Alter comment table, drop chat_id
        $this->dropForeignKey('fk_comment_chat', Comment::tableName());
        $this->dropColumn(Comment::tableName(), 'chat_id');

        // Drop project_report table
        $this->dropForeignKey('fk_project_report_project', ProjectReport::tableName());
        $this->dropForeignKey('fk_project_report_report', ProjectReport::tableName());
        $this->dropTable(ProjectReport::tableName());

        // Drop report_user table
        $this->dropForeignKey('fk_report_user_report', ReportUser::tableName());
        $this->dropForeignKey('fk_report_user_user', ReportUser::tableName());
        $this->dropForeignKey('fk_report_user_role', ReportUser::tableName());
        $this->dropTable(ReportUser::tableName());

        // Drop report table
        $this->dropForeignKey('fk_report_creator', Report::tableName());
        $this->dropTable(Report::tableName());

        // Drop project table
        $this->dropForeignKey('fk_project_parent', Project::tableName());
        $this->dropForeignKey('fk_project_creator', Project::tableName());
        $this->dropTable(Project::tableName());
    }
}
