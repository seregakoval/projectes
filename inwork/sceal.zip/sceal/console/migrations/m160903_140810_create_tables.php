<?php

use yii\db\Migration;
use common\models\User;
use common\models\Metric;
use common\models\Revision;
use common\models\MetricValue;
use common\models\Permission;

class m160903_140810_create_tables extends Migration
{
    public function up()
    {
        $options = null;
        if ($this->db->driverName === 'mysql') {
            $options = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        // Create metric table
        $this->createTable(Metric::tableName(), [
            'id'            => $this->primaryKey(),
            'parent_id'     => $this->integer(),
            'creator_id'    => $this->integer(),
            'name'          => $this->string(255)->notNull(),
            'description'   => $this->text(),
            'type'          => Metric::getEnumForType(),
            'is_additive'   => $this->boolean()->notNull()->defaultValue(0),
            'is_positive'   => $this->boolean()->notNull()->defaultValue(0),
            'is_complex'    => $this->boolean()->notNull()->defaultValue(0),
            'currency_unit' => $this->string(3),
            'decimals'      => $this->integer(),
            'source'        => $this->string(30),   // ?
            'formula'       => $this->text(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_parent_id', Metric::tableName(), 'parent_id');
        $this->addForeignKey('fk_metric_parent_id', Metric::tableName(), 'parent_id', Metric::tableName(), 'id', 'SET NULL', 'CASCADE');
        $this->createIndex('i_creator_id', Metric::tableName(), 'creator_id');
        $this->addForeignKey('fk_metric_creator_id', Metric::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create revision table (for metric_value)
        $this->createTable(Revision::tableName(), [
            'id'            => $this->primaryKey(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', Revision::tableName(), 'creator_id');
        $this->addForeignKey('fk_revision_creator_id', Revision::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create metric_value table
        $this->createTable(MetricValue::tableName(), [
            'metric_id'     => $this->integer(),
            'frequency'     => MetricValue::getEnumForFrequency(),
            'key'           => $this->date()->notNull(),
            'revision_id'   => $this->integer(),
            'is_current'    => $this->boolean()->null()->defaultValue(null),
            'value'         => $this->double(),
            'value_im'      => $this->double()->notNull()->defaultValue(0),
            'is_infinity'   => 'tinyint NOT NULL DEFAULT 0',
        ], $options);
        $this->addPrimaryKey('pk_metric_value', MetricValue::tableName(), ['metric_id', 'frequency', 'key', 'revision_id']);

        $this->createIndex('u_current_revision', MetricValue::tableName(), ['metric_id', 'frequency', 'key', 'is_current'], true);
        $this->createIndex('i_metric_id', MetricValue::tableName(), 'metric_id');
        $this->addForeignKey('fk_metric_value_metric', MetricValue::tableName(), 'metric_id', Metric::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->createIndex('i_revision_id', MetricValue::tableName(), 'revision_id');
        $this->addForeignKey('fk_metric_value_revision', MetricValue::tableName(), 'revision_id', Revision::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Create permission table
        $this->createTable(Permission::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(255)->notNull(),
            'description'   => $this->text(),
        ], $options);
        $this->createIndex('u_name', Permission::tableName(), 'name', true);
    }

    public function down()
    {
        // Drop permission table
        $this->dropTable(Permission::tableName());

        // Drop metric_value table
        $this->dropForeignKey('fk_metric_value_metric', MetricValue::tableName());
        $this->dropForeignKey('fk_metric_value_revision', MetricValue::tableName());
        $this->dropTable(MetricValue::tableName());

        // Drop revision table
        $this->dropForeignKey('fk_revision_creator_id', Revision::tableName());
        $this->dropTable(Revision::tableName());

        // Drop metric table
        $this->dropForeignKey('fk_metric_parent_id', Metric::tableName());
        $this->dropForeignKey('fk_metric_creator_id', Metric::tableName());
        $this->dropTable(Metric::tableName());
    }
}
