<?php

use yii\db\Migration;
use common\models\User;
use common\models\Priority;
use common\models\Label;
use common\models\Task;
use common\models\TaskLabel;
use common\models\TaskList;
use common\models\TaskListTask;

class m160906_081441_task_label_priority extends Migration
{
    public function up()
    {
        $options = null;
        if ($this->db->driverName === 'mysql') {
            $options = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        // Create priority table
        $this->createTable(Priority::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(),
            'description'   => $this->text(),
        ], $options);

        // Create label table
        $this->createTable(Label::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(),
            'description'   => $this->text(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', Label::tableName(), 'creator_id');
        $this->addForeignKey('fk_label_creator', Label::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create task table
        $this->createTable(Task::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(),
            'description'   => $this->text(),
            'goal'          => $this->text(),
            'start_date'    => $this->date(),
            'due_date'      => $this->date(),
            'completed_at'  => $this->integer(),
            'estimate'      => $this->integer(),
            'priority_id'   => $this->integer(),
            'is_private'    => $this->boolean()->notNull(),
            'progress'      => $this->integer(),
            'status'        => $this->string(),
            'creator_id'    => $this->integer(),
            'completer_id'  => $this->integer(),
            'is_parent_depend' => $this->boolean()->notNull(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_priority_id', Task::tableName(), 'priority_id');
        $this->addForeignKey('fk_task_priority', Task::tableName(), 'priority_id', Priority::tableName(), 'id', 'SET NULL', 'CASCADE');
        $this->createIndex('i_creator_id', Task::tableName(), 'creator_id');
        $this->addForeignKey('fk_task_creator', Task::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');
        $this->createIndex('i_completer_id', Task::tableName(), 'completer_id');
        $this->addForeignKey('fk_task_completer', Task::tableName(), 'completer_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create task_label table
        $this->createTable(TaskLabel::tableName(), [
            'task_id'       => $this->integer(),
            'label_id'       => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_task_label', TaskLabel::tableName(), ['task_id', 'label_id']);
        $this->createIndex('u_label_task', TaskLabel::tableName(), ['label_id', 'task_id'], true);
        $this->addForeignKey('fk_task_label_task', TaskLabel::tableName(), 'task_id', Task::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_task_label_label', TaskLabel::tableName(), 'label_id', Label::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Create task_list table
        $this->createTable(TaskList::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(),
            'description'   => $this->text(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', TaskList::tableName(), 'creator_id');
        $this->addForeignKey('fk_task_list_creator', TaskList::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create task_list_task table
        $this->createTable(TaskListTask::tableName(), [
            'task_list_id'  => $this->integer(),
            'task_id'       => $this->integer(),
        ], $options);
        $this->addPrimaryKey('ok_task_list_task', TaskListTask::tableName(), ['task_list_id', 'task_id']);
        $this->createIndex('u_task_task_list', TaskListTask::tableName(), ['task_id', 'task_list_id'], true);
        $this->addForeignKey('fk_task_list_task_task_list', TaskListTask::tableName(), 'task_list_id', TaskList::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_task_list_task_task', TaskListTask::tableName(), 'task_id', Task::tableName(), 'id', 'CASCADE', 'CASCADE');
    }

    public function down()
    {
        // Drop task_list_task table
        $this->dropForeignKey('fk_task_list_task_task_list', TaskListTask::tableName());
        $this->dropForeignKey('fk_task_list_task_task', TaskListTask::tableName());
        $this->dropTable(TaskListTask::tableName());

        // Drop task_list table
        $this->dropForeignKey('fk_task_list_creator', TaskList::tableName());
        $this->dropTable(TaskList::tableName());

        // Drop task_label table
        $this->dropForeignKey('fk_task_label_task', TaskLabel::tableName());
        $this->dropForeignKey('fk_task_label_label', TaskLabel::tableName());
        $this->dropTable(TaskLabel::tableName());

        // Drop task table
        $this->dropForeignKey('fk_task_label', Task::tableName());
        $this->dropForeignKey('fk_task_priority', Task::tableName());
        $this->dropForeignKey('fk_task_creator', Task::tableName());
        $this->dropForeignKey('fk_task_completer', Task::tableName());
        $this->dropTable(Task::tableName());

        // Drop label table
        $this->dropForeignKey('fk_label_creator', Label::tableName());
        $this->dropTable(Label::tableName());

        // Drop priority table
        $this->dropTable(Priority::tableName());
    }
}
