<?php

use yii\db\Migration;
use common\models\User;
use common\models\Task;
use common\models\Role;
use common\models\TaskUser;
use common\models\Tag;
use common\models\TaskTag;
use common\models\Chat;
use common\models\Comment;
use common\models\TaskChat;

class m160907_063058_task_tag_chat_comment extends Migration
{
    public function up()
    {
        $options = null;
        if ($this->db->driverName === 'mysql') {
            $options = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        // Create task_user table
        $this->createTable(TaskUser::tableName(), [
            'task_id'       => $this->integer(),
            'user_id'       => $this->integer(),
            'role_id'       => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_task_user', TaskUser::tableName(), ['task_id', 'user_id']);
        $this->createIndex('u_user_task', TaskUser::tableName(), ['user_id', 'task_id'], true);
        $this->addForeignKey('fk_task_user_task', TaskUser::tableName(), 'task_id', Task::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_task_user_user', TaskUser::tableName(), 'user_id', User::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->createIndex('i_role_id', TaskUser::tableName(), 'role_id');
        $this->addForeignKey('fk_task_user_role', TaskUser::tableName(), 'role_id', Role::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Create tag table
        $this->createTable(Tag::tableName(), [
            'id'            => $this->primaryKey(),
            'name'          => $this->string(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('u_creator_id_name', Tag::tableName(), ['creator_id', 'name'], true);
        $this->addForeignKey('fk_tag_creator', Tag::tableName(), 'creator_id', User::tableName(), 'id', 'SET NULL', 'CASCADE');

        // Create task_tag table
        $this->createTable(TaskTag::tableName(), [
            'task_id'       => $this->integer(),
            'tag_id'        => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_task_tag', TaskTag::tableName(), ['task_id', 'tag_id']);
        $this->createIndex('u_tag_task', TaskTag::tableName(), ['tag_id', 'task_id'], true);
        $this->addForeignKey('fk_task_tag_task', TaskTag::tableName(), 'task_id', Task::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_task_tag_tag', TaskTag::tableName(), 'tag_id', Tag::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Create chat table
        $this->createTable(Chat::tableName(), [
            'id'            => $this->primaryKey(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);

        // Create comment table
        $this->createTable(Comment::tableName(), [
            'id'            => $this->primaryKey(),
            'message'       => $this->text(),
            'creator_id'    => $this->integer(),
            'created_at'    => $this->integer(),
            'updated_at'    => $this->integer(),
        ], $options);
        $this->createIndex('i_creator_id', Comment::tableName(), 'creator_id', true);
        $this->addForeignKey('fk_comment_creator', Comment::tableName(), 'creator_id', User::tableName(), 'id', 'CASCADE', 'CASCADE');

        // Create task_chat table
        $this->createTable(TaskChat::tableName(), [
            'task_id'       => $this->integer(),
            'chat_id'       => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_task_chat', TaskChat::tableName(), ['task_id', 'chat_id']);
        $this->createIndex('u_chat_task', TaskChat::tableName(), ['chat_id', 'task_id'], true);
        $this->addForeignKey('fk_task_chat_task', TaskChat::tableName(), 'task_id', Task::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_task_chat_chat', TaskChat::tableName(), 'chat_id', Chat::tableName(), 'id', 'CASCADE', 'CASCADE');
    }

    public function down()
    {
        // Drop task_chat table
        $this->dropForeignKey('fk_task_chat_task', TaskChat::tableName());
        $this->dropForeignKey('fk_task_chat_chat', TaskChat::tableName());
        $this->dropTable(TaskChat::tableName());

        // Create comment table
        $this->dropForeignKey('fk_comment_creator', Comment::tableName());
        $this->dropTable(Comment::tableName());

        // Drop chat table
        $this->dropTable(Chat::tableName());

        // Drop task_tag table
        $this->dropForeignKey('fk_task_tag_task', TaskTag::tableName());
        $this->dropForeignKey('fk_task_tag_tag', TaskTag::tableName());
        $this->dropTable(TaskTag::tableName());

        // Drop tag table
        $this->dropForeignKey('fk_tag_creator', Tag::tableName());
        $this->dropTable(Tag::tableName());

        // Drop task_user table
        $this->dropForeignKey('fk_task_user_task', TaskUser::tableName());
        $this->dropForeignKey('fk_task_user_user', TaskUser::tableName());
        $this->dropForeignKey('fk_task_user_role', TaskUser::tableName());
        $this->dropTable(TaskUser::tableName());
    }
}
