<?php

use yii\db\Migration;
use common\models\Company;
use common\models\CompanyCompany;

class m161020_075959_company_company extends Migration
{
    public function up()
    {
        $options = null;
        if ($this->db->driverName === 'mysql') {
            $options = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        // Create company_company table
        $this->createTable(CompanyCompany::tableName(), [
            'company_id'        => $this->integer(),
            'company_child_id'  => $this->integer(),
        ], $options);
        $this->addPrimaryKey('pk_company_company', CompanyCompany::tableName(), ['company_id', 'company_child_id']);
        $this->addForeignKey('fk_company_company_company', CompanyCompany::tableName(), 'company_id', Company::tableName(), 'id', 'CASCADE', 'CASCADE');
        $this->addForeignKey('fk_company_company_child_company', CompanyCompany::tableName(), 'company_child_id', Company::tableName(), 'id', 'CASCADE', 'CASCADE');
    }

    public function down()
    {
        // Drop company_company table
        $this->dropForeignKey('fk_company_company_company', CompanyCompany::tableName());
        $this->dropForeignKey('fk_company_company_child_company', CompanyCompany::tableName());
        $this->dropTable(CompanyCompany::tableName());
    }
}
