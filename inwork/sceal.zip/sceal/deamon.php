<?php

while (true) {
    echo date('Y-m-d H:i:s') . PHP_EOL;
    sleep(1);
}
