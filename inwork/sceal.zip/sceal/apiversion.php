#!/usr/bin/env php
<?php

/**
 * @copyright (c) 2016, GBKSOFT
 * API version workflow
 * helper script.
 * Increase API/swagger cersion
 * v1.0
 */

$param_file = __DIR__."/api/config/params.php";
$swagger_file = __DIR__."/api/web/swagger/swagger.json";

if (!file_exists($param_file)) {
    echo "Error! Can't find param file `{$param_file}`";
    exit(-1);
}

if (!file_exists($swagger_file)) {
    echo "Error! Can't find swagger file `{$swagger_file}`";
    exit(-1);
}

$params = require($param_file);
$apiversion = $params['apiversion'];
echo "\nCurrent API version is ". $apiversion ."\n";


// Make new versions
list($major_curr, $minor_curr, $build_curr) = explode('.', $apiversion);
$version_next_major = implode('.', [($major_curr+1), 0, 0]);
$version_next_minor = implode('.', [$major_curr, ($minor_curr+1), 0]);
$version_next_build = implode('.', [$major_curr, $minor_curr, ($build_curr+1)]);

echo "\nNext API version:";
echo "\n[1] - {$version_next_major} (new milestone)";
echo "\n[2] - {$version_next_minor} (new API method, new task)";
echo "\n[3] - {$version_next_build} (minor fixes)";

$newversion = null;
while (is_null($newversion)) {
    echo "\n  Your choice [1-3], or \"q\" to skip: ";
    $answer = strtolower(trim(fgets(STDIN)));
    
    if ($answer == 'q') {
        exit(0);
    }
    
    if (!in_array($answer, ["1","2","3"], true)) {
        continue;
    }
    
    list($major,$minor,$build) = explode('.', $apiversion);
    switch ($answer) {
        case "1":
            $newversion = $version_next_major;
            break;
        case "2":
            $newversion = $version_next_minor;
            break;
        case "3":
            $newversion = $version_next_build;
            break;
    }
    
    echo "\n New API version is ". $newversion ."\n";
    echo "\n Save new version? (y/n): ";
    $answer = strtolower(trim(fgets(STDIN)));
    if ($answer !== 'y') {
        $newversion = null;
    }
}

// Save new API vesrion (in yii params)
$content = file_get_contents($param_file);
$pattern = '/[\'"]apiversion[\'"] ?=> ?[\'"]'.$apiversion.'[\'"]/s';
$replacement = "'apiversion' => '{$newversion}'";
$new_content = preg_replace($pattern, $replacement, $content);
file_put_contents($param_file, $new_content);

// Save new API vesrion (in swagger.json)
$swagger_content = file_get_contents($swagger_file);
$swagger_pattern = '/"version": "[0-9]+\.[0-9]+\.[0-9]+"/';
$swagger_replacement = '"version": "'. $newversion .'"';
$new_swagger_content = preg_replace($swagger_pattern, $swagger_replacement, $swagger_content);
file_put_contents($swagger_file, $new_swagger_content);


echo "\n Make git commit? (y/n): ";
$answer = strtolower(trim(fgets(STDIN)));
if ($answer !== 'y') {
    exit(0);
}

echo "\n Adding {$param_file} to git... ";
exec('git add '. $param_file);
echo " [OK]\n\n";

echo "\n Adding {$swagger_file} to git... ";
exec('git add '. $swagger_file);
echo " [OK]\n\n";

echo "\n Commit ... ";
exec('git commit -m "New API version  '. $newversion .'"');
echo " [OK]\n\n";

exit(0);
