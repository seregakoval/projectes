module.exports = HttpProviderConfig;

HttpProviderConfig.$inject = ['$httpProvider'];

function HttpProviderConfig($httpProvider) {
  $httpProvider.interceptors.push(Interceptor);
}

Interceptor.$inject = ['$q', '$injector'];

function Interceptor($q, $injector) {

  var errorsHandlers = {
    401: function (error) {
      $injector.get('$state').go('login', null, {location: false});
    }
  };

  return {
    request: function (config) {
      if (config.url.search(/^\/api\//) + 1) {
        config.headers.Authorization = $injector.get('Acl').user.token;
      }
      return config;
    },
    requestError: function (rejection) {
      return $q.reject(rejection);
    },
    responseError: function (rejection) {
      if (errorsHandlers[rejection.status]) {
        errorsHandlers[rejection.status](rejection);
      }

      return $q.reject(rejection);
    }
  };
}
