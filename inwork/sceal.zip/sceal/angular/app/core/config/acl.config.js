module.exports = aclConfig;

aclConfig.$inject = [
  'AclProvider'
];

function aclConfig(AclProvider) {
  AclProvider.config({
    storage: 'localStorage',
    storageKey: 'ScaleAcl',
    defaultRole: 'guest',
    emptyActionDefault: true,
    defaultUser: {
      name: 'guest'
    },
    permissions: {
      guest: {
        actions: {
        }
      },
      user: {
        actions: {
        }
      },
      proUser: {
        actions: {
        }
      },
      admin: {
        actions: {
        }
      }
    }
  });
}
