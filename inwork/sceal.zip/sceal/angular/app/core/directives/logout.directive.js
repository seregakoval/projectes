module.exports = logout;

logout.$inject = ['$state'];

function logout($state) {
   var directive = {
      restrict: 'A',
      scope: {},
      link: Link
   };

   function Link($scope, $elemet) {
      $elemet.bind('click', function () {
        $state.go('root.app.home');
      });
   }

   return directive;
}
