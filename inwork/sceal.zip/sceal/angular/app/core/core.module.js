module.exports = 'core';

angular.module('core', [])
    .config(require('./config/http.config'))
    .config(require('./config/acl.config'))
    /*directives*/
    .directive('logout', require('./directives/logout.directive'))
    .directive('backBtn', require('./directives/backBtn.directive'))
