module.exports = authRoutes;

authRoutes.$inject = ['$stateProvider'];

function authRoutes($stateProvider) {
  $stateProvider

    .state('root.app.login', {
      url: '/login',
      views: {
        '': {
          template: '<login></login>',
        }
      }
  })
}
