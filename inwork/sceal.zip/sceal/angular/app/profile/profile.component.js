module.exports = {
  bindings: {},
  controller: ProfileController,
  controllerAs: 'vm',
  templateUrl: ['App', function(App) {
    return App.template('./profile/profile');
  }]
};

ProfileController.$inject = [];

function ProfileController() {
  var vm = this;


}
