module.exports = 'profile';

angular.module('profile', [])
    .config(require('./profile.routes'))
    .component('profile',require('./profile.component'))
