module.exports = profileRoutes;

profileRoutes.$inject = ['$stateProvider'];

function profileRoutes ($stateProvider) {

   $stateProvider
     .state('root.app.profile', {
        url: '/profile',
        requiresLogin: true,
        permissions : ['admin'], //test access
        views :{
          '' : {
            template: '<profile></profile>'
          }
        }
     })
}
