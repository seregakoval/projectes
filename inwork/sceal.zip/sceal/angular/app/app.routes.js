module.exports = appRoutes;

appRoutes.$inject = ['$stateProvider', '$urlRouterProvider'];

function appRoutes($stateProvider, $urlRouterProvider) {

  $urlRouterProvider.otherwise(function ($injector) {
    var $state = $injector.get('$state');
    $state.go('root.app.home', null, {});
  });

  $stateProvider

      .state('root', {
        abstract: true,
        template: '<div class="dashboard">' +
            '<div ui-view="header"></div>' +
            '<div ui-view="sidebar"></div>' +
            '<div ui-view=""></div>' +
            '<div ui-view="footer"></div>' +
            '</div>'
      })

      .state('root.app', {
        abstract: true,
        views: {
          'header': {
            template: '<header></header>'
          },
          'sidebar': {
            template: '<sidebar></sidebar>'
          },
          '': {
            template: '<div ui-view></div>'
          },
          'footer': {
            template: '<footer></footer>'
          }
        }
      });

}
