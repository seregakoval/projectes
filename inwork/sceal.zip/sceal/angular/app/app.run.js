module.exports = runFun;

runFun.$inject = ['$rootScope'];

function runFun($rootScope) {

  $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams) {

  });

}
