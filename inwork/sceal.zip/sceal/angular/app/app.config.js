module.exports = config;

config.$inject = ['$locationProvider'];

function config($locationProvider) {
  var apiUrl = "/api";

  $locationProvider.html5Mode({enabled: true, requireBase: false}).hashPrefix('!');

}

