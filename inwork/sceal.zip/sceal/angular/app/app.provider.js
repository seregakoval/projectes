/**
 * Style Guide
 * @link https://github.com/johnpapa/angular-styleguide
 */

module.exports = AppProvider;

AppProvider.$inject = [];

function AppProvider() {
  var provider = this;

  provider.config = {};
  provider.template = template;
  provider.$get = App;

  App.$inject = [
    '$auth',
    '$state'
  ];

  function App($auth, $state) {
    var app = {
      template: template
    };

    Object.defineProperties(app, {
      config: {
        get: function() {
          return provider.config;
        }
      }
    });

    return app;
  }

  /**
   * Get template path
   *
   * @param {string} path
   * @returns {string}
   */
  function template(path) {
    return 'templates/' + path + '.html';
  }
}
