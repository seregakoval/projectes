module.exports = 'home';

angular.module('home', [])
    .config(require('./home.routes'))
    .component('home',require('./home.component'))
