module.exports = {
   bindings:     {},
   controller:   HomeController,
   controllerAs: 'vm',
   templateUrl:  ['App', function (App) {
     return App.template('./home/home');
   }]
};

HomeController.$inject = [];

function HomeController () {
   var vm = this;

}
