module.exports = homeRoutes;

homeRoutes.$inject = ['$stateProvider'];

function homeRoutes ($stateProvider) {

   $stateProvider
     .state('root.app.home', {
        url: '/',
        views :{
          '' : {
            template: '<home></home>'
          }
        }
     })
}
