module.exports = {
   bindings:     {},
   controller:   HeaderController,
   controllerAs: 'vm',
   templateUrl:  ['App', function (App) {
     return App.template('layout/header/header');
   }]
};

HeaderController.$inject = [];

function HeaderController () {
   var vm = this;

   console.log('header component')
}
