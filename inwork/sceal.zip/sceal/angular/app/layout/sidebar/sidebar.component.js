module.exports = {
   bindings:     {},
   controller:   SidebarController,
   controllerAs: 'vm',
   templateUrl:  ['App', function (App) {
     return App.template('layout/sidebar/sidebar');
   }]
};

SidebarController.$inject = [];

function SidebarController () {
   var vm = this;

   console.log('sidebar component')
}
