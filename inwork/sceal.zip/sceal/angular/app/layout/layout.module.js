module.exports = 'layout';

angular.module('layout', [])
   .component('header',require('./header/header.component'))
   .component('sidebar',require('./sidebar/sidebar.component'))
   .component('footer',require('./footer/footer.component'));
