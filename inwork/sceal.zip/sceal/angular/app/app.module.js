angular.module('App', [
   "ct.ui.router.extras",
   "ui.bootstrap",
   "satellizer",
   "toaster",
   "acl",

   require('./core/core.module'),
   require('./layout/layout.module'),
   require('./home/home.module'),
   require('./auth/auth.module'),
   require('./profile/profile.module')
])
.provider('App', require('./app.provider'))
.config  (require('./app.config'))
.run  (require('./app.run'))
.config  (require('./app.routes'));

angular.element(document).ready(function () {
   angular.bootstrap(this, ['App']);
});
