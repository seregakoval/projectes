<?php
namespace common\components;

/**
 * Customization variants output fields for models (method "fields")
 * 
 * Use example
 * -----
 * 
 * In ActiveRecord model:
 * 
 * ```php
 * class User extends ActiveRecord implements IdentityInterface
 * 
 *     use \common\components\ModelCustomFieldsTrait;
 * 
 *     ...
 *     public function fields()
 *     {
 *         return $this->customFieldsHandler([
 *             'id',
 *             'username',
 *             'profile',
 *         ]);
 *     }
 *     ...
 * }
 * ```
 * 
 * In controller:
 * 
 * ```php
 * class ApiController extends \yii\rest\ActiveController
 * {
 *     ....
 *     public function actionUser($id)
 *     {
 *         $user = \common\models\User::findOne($id);
  *        return $user->enableCustomFields([
 *             'id',
 *             'profile.id',
 *             'profile.first_name',
 *             'profile.second_name',
 *         ]);
 *     }
 *     ....
 * }
 * ```
 */
trait ModelCustomFieldsTrait {
    
    public $customFieldsEnabled = false;
    public $customFieldsList = [];
    
    /**
     * Enable custom fields
     */
    public function enableCustomFields($fields = [])
    {
        $this->customFieldsEnabled = true;
        $this->customFieldsList = $fields;
        return $this;
    }
    
    /**
     * Disable custom fields
     */
    public function disableCustomFields()
    {
        $this->customFieldsEnabled = false;
        return $this;
    }
    
    /**
     * Set handler for fields (point's separator)
     */
    public function customFieldsHandler($defaultFields = [])
    {
        if (!$this->customFieldsEnabled) {
            return $defaultFields;
        }
        
        $fieldsTree = [];
        $fields = [];
        foreach ($this->customFieldsList as $field => $value) {
            $chain = explode('.', is_int($field) ? $value : $field, 2);
            $val = is_int($field) ? null : $value;
            
            switch (sizeof($chain)) {
                case 1:
                    $fieldsTree[$chain[0]] = $val;
                    break;
                case 2:
                    $fieldsTree[$chain[0]][$chain[1]] = $val;
                    break;
            }
        }
        
        foreach ($fieldsTree as $field => $value) {
            if (is_array($value)) {
                if ($this->getRelation($field, false) instanceof \yii\db\ActiveQueryInterface) {
                    if ($this->{$field} && $this->{$field} instanceof self) {
                        $this->{$field}->enableCustomFields($value);
                        $fields[] = $field;
                    } else {
                        $fields[$field] = function(){ return null; }; // hack for return NULL ($this->{$field} is 0, need NULL)
                    }
                } else {
                    if (isset($defaultFields[$field])) {
                        $fields[$field] = $defaultFields[$field];
                    }
                }
            } else {
                if (null === $value) {
                    if (isset($defaultFields[$field])) {
                        $fields[$field] = $defaultFields[$field];
                    } else {
                        $fields[] = $field;
                    }
                } else {
                    $fields[$field] = $value;
                }
            }
            
        }
        
        return $fields;
    }
}

