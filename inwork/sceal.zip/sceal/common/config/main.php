<?php
return [
    'bootstrap' => [
        'tokens'
    ],
    'timeZone' => 'UTC',
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
    ],
    'modules' => [
        'tokens' => [
            'class' => 'gbksoft\modules\tokens\Module',
            'userClass' => common\models\User::class,
            'urlRulePrefix' => 'v1/',
            'on beforeControllerBehavior' => function($event) {
                $event->data = common\overrides\rest\ActiveController::getDefaultBehaviors();
            },
        ],
    ],
    'on beforeRequest' => function ($event) {
        date_default_timezone_set($event->sender->timeZone);
//        header('content-type: application/json');
//        echo json_encode(Yii::$app->getUrlManager()->rules);die;
        if ($event->sender instanceof \yii\web\Application) {
            if (file_exists(__DIR__ . '/../../deploy.lock')) {
                throw new yii\web\HttpException(503);
            }
        }
    }
];
