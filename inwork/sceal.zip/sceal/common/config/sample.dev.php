<?php
/**
 * Copy sample.dev.php to dev.php 
 * if you need to roverload config for local development
 * Or just put your config into .env file
 */
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host='. (getenv('DB_HOST')?:'gbksoft.net') .';dbname='. (getenv('DB_NAME')?:'put db name here'),
            'username' => (getenv('DB_USER')?:'put user name here'),
            'password' => (getenv('DB_PASS')?:'put password here'),
            'charset' => 'utf8',
        ],
    ],
];
