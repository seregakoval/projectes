<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%permission}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 */
class Permission extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%permission}}';
    }
}
