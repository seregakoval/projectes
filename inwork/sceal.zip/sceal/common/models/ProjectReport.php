<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%project_report}}".
 *
 * @property integer $project_id
 * @property integer $report_id
 */
class ProjectReport extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%project_report}}';
    }
}
