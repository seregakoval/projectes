<?php

namespace common\models;

use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%task}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 * @property integer $label_id
 * @property string $goal
 * @property string $start_date
 * @property string $due_date
 * @property integer $completed_at
 * @property integer $estimate
 * @property integer $priority_id
 * @property integer $is_private                Is the for the user that created it only.
 * @property integer $progress                  Task progress in %
 * @property string $status                     Records the status of the task in terms or Not Started, work in progress, delayed, Late… Can refer to another table that caputers the date for a specific report
 * @property integer $creator_id
 * @property integer $completer_id
 * @property integer $is_parent_depend          Is the parent task dependant on this task?
 * @property integer $created_at
 * @property integer $updated_at
 */
class Task extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%task}}';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }
}
