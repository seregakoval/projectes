<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%metric_value}}".
 *
 * @property integer $metric_id         Metric id
 * @property string $frequency          Frequency: daily, weekly, monthly, quarterly, yearly
 * @property string $key                Date of metric value
 * @property integer $revision_id       Revision (version) of value
 * @property integer $is_current        Is current revision?
 * @property float $value               Metric value (real)
 * @property float $value_im            Metric value imaginary
 * @property integer $is_infinity       Is value infinity?: -1 => -∞; 1 => +∞
 */
class MetricValue extends ActiveRecord
{
    const FREQ_DAILY = 'daily';
    const FREQ_WEEKLY = 'weekly';
    const FREQ_MONTHLY = 'monthly';
    const FREQ_QUARTERLY = 'quarterly';
    const FREQ_YEARLY = 'yearly';
    const FREQUENCIES = [
        self::FREQ_DAILY,
        self::FREQ_WEEKLY,
        self::FREQ_MONTHLY,
        self::FREQ_QUARTERLY,
        self::FREQ_YEARLY,
    ];

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%metric_value}}';
    }

    public static function getEnumForFrequency()
    {
        return 'ENUM(' . implode(', ', array_map(function ($value) {
            return '"' . $value . '"';
        }, static::FREQUENCIES)) . ') NOT NULL';
    }
}
