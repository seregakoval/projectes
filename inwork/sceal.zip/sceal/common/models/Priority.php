<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%priority}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 */
class Priority extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%priority}}';
    }
}
