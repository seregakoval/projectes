<?php

namespace common\models;

use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%metric}}".
 *
 * @property integer $id
 * @property integer $parent_id         Parent metric id
 * @property integer $creator_id        Id of user who created the metric
 * @property string $name               Name of metric
 * @property string $description        Description of metric
 * @property string $type               Metric type: number, currency, percent, time
 * @property integer $is_additive       Is metric additive?
 * @property integer $is_positive       Is metric positive?
 * @property integer $is_complex        Is complex metric? (with formula)
 * @property string $currency_unit      Metric currency unit (USD, EUR, ...)
 * @property integer $decimals          Metric decimal places
 * @property string $source             Metric source (manual, ???)
 * @property string $formula            Metric formula (with another metric ids)
 * @property integer $created_at
 * @property integer $updated_at
 */
class Metric extends ActiveRecord
{
    const METRIC_TYPES = ['number', 'currency', 'percent', 'time'];

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%metric}}';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }

    public static function getEnumForType()
    {
        return 'ENUM(' . implode(', ', array_map(function ($value) {
            return '"' . $value . '"';
        }, static::METRIC_TYPES)) . ') NOT NULL DEFAULT "number"';
    }

    public static function adjustDate(DateTime $dateTime, $frequency)
    {
        $dateTime = clone $dateTime;
        switch ($frequency) {
            case MetricValue::FREQ_DAILY:
                return $dateTime;
            case MetricValue::FREQ_WEEKLY:
                $adj = intval($dateTime->format('N')) - 1;
                return $dateTime->sub(new DateInterval('P' . $adj . 'D'));
            case MetricValue::FREQ_MONTHLY:
                $adj = intval($dateTime->format('j')) - 1;
                return $dateTime->sub(new DateInterval('P' . $adj . 'D'));
            case MetricValue::FREQ_QUARTERLY:
                $dateTime = self::adjustDate($dateTime, MetricValue::FREQ_MONTHLY);
                $adj = (intval($dateTime->format('n')) - 1) % 3;
                return $dateTime->sub(new DateInterval('P' . $adj . 'M'));
            case MetricValue::FREQ_ANNUAL:
                $dateTime = self::adjustDate($dateTime, MetricValue::FREQ_MONTHLY);
                $adj = intval($dateTime->format('n')) - 1;
                return $dateTime->sub(new DateInterval('P' . $adj . 'M'));
            default:
                throw new \Exception("Invalid frequency: '$frequency'");
        }
    }

    public static function keyToDateTime($key)
    {
        return DateTime::createFromFormat(self::VALUE_KEY_FORMAT . ' H:i:s', $key . ' 00:00:00', new DateTimeZone('UTC'));
    }

    public static function dateTimeToKey(DateTime $dateTime)
    {
        return $dateTime->format(self::VALUE_KEY_FORMAT);
    }

    public static function getInterval($frequency, $n = 1)
    {
        $n = intval($n);
        switch ($frequency) {
            case MetricValue::FREQ_DAILY:
                return new DateInterval('P' . $n . 'D');
            case MetricValue::FREQ_WEEKLY:
                return new DateInterval('P' . ($n * 7) . 'D');
            case MetricValue::FREQ_MONTHLY:
                return new DateInterval('P' . ($n) . 'M');
            case MetricValue::FREQ_QUARTERLY:
                return new DateInterval('P' . ($n * 3) . 'M');
            case MetricValue::FREQ_ANNUAL:
                return new DateInterval('P' . $n . 'Y');
            default:
                throw new \Exception("Invalid frequency: '$frequency'");
        }
    }

    public static function isValidValueKey($key, $frequency)
    {
        $keyDateTime = self::keyToDateTime($key);
        $validDateTime = self::adjustDate($keyDateTime, $frequency);
        return $key === self::dateTimeToKey($validDateTime);
    }

    public function getDerivedFrom()
    {
        if (!$this->is_complex || empty($this->formula)) {
            return [];
        }
        if (preg_match_all('/\\[([^\\[\\]]*)\\]/', $this->formula, $matches)) {
            $ids = array_map('intval', $matches[1]);
            return array_values(array_unique($ids));
        } else {
            return [];
        }
    }

    public function getDerivedFromMetrics()
    {
        return self::find()->andWhere(['id' => $this->derivedFrom])->all();
    }
}
