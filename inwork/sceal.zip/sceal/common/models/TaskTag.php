<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%task_tag}}".
 *
 * @property integer $task_id
 * @property integer $tag_id
 */
class TaskTag extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%task_tag}}';
    }
}
