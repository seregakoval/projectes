<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%role_permission}}".
 *
 * @property integer $role_id
 * @property integer $permission_id
 */
class RolePermission extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%role_permission}}';
    }
}
