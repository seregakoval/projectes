<?php

namespace common\models;

use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%task_list}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 * @property integer $creator_id
 * @property integer $created_at
 * @property integer $updated_at
 */
class TaskList extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%task_list}}';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }
}
