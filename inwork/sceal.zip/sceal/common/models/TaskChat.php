<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%task_chat}}".
 *
 * @property integer $task_id
 * @property integer $chat_id
 */
class TaskChat extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%task_chat}}';
    }
}
