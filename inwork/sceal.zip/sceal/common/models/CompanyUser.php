<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%company_user}}".
 *
 * @property integer $company_id
 * @property integer $user_id
 */
class CompanyUser extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%company_user}}';
    }
}
