<?php

namespace common\models;

use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%report}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 * @property string $due_date
 * @property integer $creator_id
 * @property integer $created_at
 * @property integer $updated_at
 */
class Report extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%report}}';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }
}
