<?php

namespace common\models;

use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%company}}".
 *
 * @property integer $id
 * @property string $name               Name of company
 * @property string $type               Type of company
 * @property integer $creator_id        Id of user who created the company
 * @property integer $created_at
 * @property integer $updated_at
 */
class Company extends ActiveRecord
{
    const TYPE_ORGANIZATION = 'organization';
    const TYPE_COMPANY = 'company';
    const TYPE_TEAM = 'team';
    const TYPES = [self::TYPE_ORGANIZATION, self::TYPE_COMPANY, self::TYPE_TEAM];

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%company}}';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }

    public static function getEnumForType()
    {
        return 'ENUM(' . implode(', ', array_map(function ($value) {
            return '"' . $value . '"';
        }, static::TYPES)) . ') NOT NULL';
    }
}
