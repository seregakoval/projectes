<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%company_company}}".
 *
 * @property integer $company_id
 * @property integer $company_child_id
 */
class CompanyCompany extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%company_company}}';
    }
}
