<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%task_list_task}}".
 *
 * @property integer $task_list_id
 * @property integer $task_id
 */
class TaskListTask extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%task_list_task}}';
    }
}
