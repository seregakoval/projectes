<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%task_label}}".
 *
 * @property integer $task_id
 * @property integer $label_id
 */
class TaskLabel extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%task_label}}';
    }
}
