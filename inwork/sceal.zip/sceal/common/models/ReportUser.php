<?php

namespace common\models;

use yii\db\ActiveRecord;

/**
 * This is the model class for table "{{%report_user}}".
 *
 * @property integer $report_id
 * @property integer $user_id
 * @property integer $role_id
 */
class ReportUser extends ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%report_user}}';
    }
}
