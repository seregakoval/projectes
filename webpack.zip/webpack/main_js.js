import './main.css' ;
document.write(require("./main_js2"));

